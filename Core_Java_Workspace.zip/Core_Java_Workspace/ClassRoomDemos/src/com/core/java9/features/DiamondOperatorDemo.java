package com.core.java9.features;

class MyGenClass<T> {
	T obj;

	public MyGenClass(T obj) {
		this.obj = obj;
	}

	public T getObj() {
		return obj;
	}

	public void process() {
		System.out.println("Processing obj...");
	}
}

public class DiamondOperatorDemo {

	public static void main(String[] args) {
		MyGenClass<String> c1 = new MyGenClass<String>("Kalyan") {
			public void process() {
				System.out.println("Processing... " + getObj());
			}
		};
		c1.process();

		MyGenClass<String> c2 = new MyGenClass<String>("Pavan")
				{
			public void process() {
				System.out.println("Processing... " + getObj());
			}
		};
		c2.process();
	}
}


