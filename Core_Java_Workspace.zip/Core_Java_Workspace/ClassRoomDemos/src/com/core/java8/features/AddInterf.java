package com.core.java8.features;

public interface AddInterf {
	public void add(int a,int b);

}
