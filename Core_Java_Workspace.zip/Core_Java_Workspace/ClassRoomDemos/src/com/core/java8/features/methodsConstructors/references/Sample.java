package com.core.java8.features.methodsConstructors.references;

public class Sample {
	private String s;
	Sample(String s) {
		this.s = s;
		System.out.println("Constructor Executed:"+s);
	}
}
