package com.core.java8.features;
/**
 * From lambda expression we can access enclosing class variables and enclosing method variables
   directly.
   The local variables referenced from lambda expression are implicitly final and hence we can�t
   perform re-assignment for those local variables otherwise we get compile time error
 */

public class InstanceLocalVariableDemo1 {
	int x = 10;
	public void m2() {
     int y = 20;
    Interface  i= ()-> {
	 System.out.println(x); //10
	 //System.out.println(y); //20
	 x = 888;
	// y = 999; //CE	 
    };
	 i.m1();
	 y = 777;
	 }
	 public static void main(String[] args) {
		 InstanceLocalVariableDemo1 t = new InstanceLocalVariableDemo1();
	 t.m2();
	 }
	 } 

