package com.core.java8.features;

/**
 * From 1.8version onwards we can write main()method inside interface andhence we can run interface
   directly from the command prompt.
 * 
 *
 */

public interface InterfaceMainMethod {

	public static void main(String[] args) {
		System.out.println("Interface Main Method");
	}
}
