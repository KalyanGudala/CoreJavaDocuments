package com.core.java8.features;

public interface InstanceVariableInterf {
	public void m1();
}
