package com.core.java8.features.streams;

/**
 * if we want to represent a group of individual objects as a single entity then
   we should go for collection.if we want to process a group of objects from the collection 
   then we should go for streams.we can create a stream object to the collection by using 
   stream()method of Collection interface.stream() method is a default method added to the 
   Collection in 1.8 version.default Stream stream()
 **/

/**
 * Filtering:
   We can configure a filter to filter elements from the collection based on some 
   boolean condition by using filter()method of Stream interface.
   public Stream filter(Predicate<T> t)
 */

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class WithStreams {
	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<Integer>();
		for(int i=0; i<=10; i++) {
			l1.add(i);
		}
		System.out.println(l1);
		List<Integer> l2 = l1.stream().filter(i->i%2==0).collect(Collectors.toList());
		System.out.println(l2);
	}
}
