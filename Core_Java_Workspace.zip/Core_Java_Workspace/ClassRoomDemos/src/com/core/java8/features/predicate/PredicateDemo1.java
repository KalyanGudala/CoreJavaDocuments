package com.core.java8.features.predicate;

import java.util.Collection;
import java.util.function.Predicate;

/**
 *Predicates ::
 *A predicate is a function with a single argument and returns boolean value.
 *To implement predicate functions in java,oracle people introduced Predicate interface in 1.8
  version(i.e.,Predicate<T>).
 *Predicate interface present in java.util.function package.
 *It�s a functional interface and it contains only one method i.e., test()
 * 
 *
 */
public class PredicateDemo1 {

	public static void main(String[] args) {
		Predicate<Integer> p = i ->(i>10);
		System.out.println(p.test(100));//true
		System.out.println(p.test(7)); // false
		//System.out.println(p.test(true)); //CE
		Predicate<String> p1= s ->(s.length() > 3);
		System.out.println(p1.test("Kalyan"));//true
		System.out.println(p1.test("gk"));//false
		Predicate<Collection> p2=c->c.isEmpty();
	}
}
