package com.core.java8.features;

public class LambdaTest {
	public static void main(String[] args)
	{
		Interf i=()->System.out.println("Sample Lambda Demo");
		i.methodone();
	}

}
