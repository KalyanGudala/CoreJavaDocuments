package com.core.java8.features;

class AddDemo implements AddInterf
{

	@Override
	public void add(int a, int b) {
		System.out.println("The value of AddDemo is:"+(a+b));		
	}
	
}

public class AddTest {
	public static void main(String[] args)
	{
		AddInterf addInterf=new AddDemo();
		addInterf.add(2,5);
	}

}
