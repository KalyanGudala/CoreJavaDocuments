package com.core.java8.features;

/**
 * Default method vs multiple inheritance
   Two interfaces can contain default method with same signature then there may be a chance of
   ambiguity problem(diamond problem) to the implementation class.to overcome this problem
   compulsory we should override default method in the implementation class otherwise we get
   compiletime error.
 * @author home
 *
 */

public class DefaultMethodInterfaceDemo implements InterfaceLeft,InterfaceRight  {

	public void m1() {
		System.out.println("Default Method Interface Demo>>>>>");
		InterfaceLeft.super.m1();
		InterfaceRight.super.m1();
	}
	
	public static void main(String[] args) {
		DefaultMethodInterfaceDemo defaultMethodInterfaceDemo=new DefaultMethodInterfaceDemo();
		defaultMethodInterfaceDemo.m1();
	}
}
