package com.core.java8.features;

public interface SqrtInterf {
	public int sqrt(int x);
}
