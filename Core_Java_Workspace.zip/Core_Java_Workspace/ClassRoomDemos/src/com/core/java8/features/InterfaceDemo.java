package com.core.java8.features;

public class InterfaceDemo implements DefaultInterface{

	public static void main(String[] args)
	{
		InterfaceDemo defaultInterface=new InterfaceDemo();
		
		defaultInterface.m1();
	}
}
