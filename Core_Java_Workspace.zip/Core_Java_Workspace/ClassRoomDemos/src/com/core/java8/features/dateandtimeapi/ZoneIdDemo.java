package com.core.java8.features.dateandtimeapi;

import java.time.LocalDate;
import java.time.Period;
import java.time.Year;
import java.time.ZoneId;

public class ZoneIdDemo {
	public static void main(String[] args) {
		ZoneId zone = ZoneId.systemDefault();
		System.out.println(zone);
		
		//Period Demo::
		LocalDate today = LocalDate.now();
		LocalDate birthday = LocalDate.of(1989,06,15);
		Period p = Period.between(birthday,today);
		System.out.printf("age is %d year %d months %d days",p.getYears(),p.getMonths(),p.getDays());
		
		//Leap Year Demo
		int n = Integer.parseInt(args[0]);
		Year y = Year.of(n);
		if(y.isLeap())
		System.out.printf("%d is Leap year",n);
		else
		System.out.printf("%d is not Leap year",n);
}
}
