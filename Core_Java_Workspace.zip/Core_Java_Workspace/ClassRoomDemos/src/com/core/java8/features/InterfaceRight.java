package com.core.java8.features;

public interface InterfaceRight {

	default void m1() {	
		System.out.println("Right Default Method");
	}
	
}
