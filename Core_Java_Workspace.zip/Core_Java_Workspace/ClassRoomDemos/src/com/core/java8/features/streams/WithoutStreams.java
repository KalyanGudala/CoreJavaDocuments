package com.core.java8.features.streams;

import java.util.ArrayList;

public class WithoutStreams {
	public static void main(String[] args) {
		ArrayList<Integer> l1 = new ArrayList<Integer>();
		for(int i=0; i<=10; i++) {
			l1.add(i);
		}
		System.out.println(l1);
		ArrayList<Integer> l2 = new ArrayList<Integer>();
		
		for(Integer I:l1)
		{
			if(I%2 == 0)
			{
				l2.add(I);
			}
		}
		System.out.println(l2);
	}

}
