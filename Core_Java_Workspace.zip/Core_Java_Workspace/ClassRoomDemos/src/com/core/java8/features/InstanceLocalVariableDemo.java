package com.core.java8.features;

/**
 * Explanation:
 *Inside lambda expression we can�t declare instance variables.
 *Whatever the variables declare inside lambda expression are simply acts as local variables
 *Within lambda expression �this� keyword represents current outer class object reference 
 *(that is current enclosing class reference in which we declare lambda expression)
 * 
 *
 */

public class InstanceLocalVariableDemo {
	
	int x=777;
	public void m2()
	{
		Interface i=()->{ //Lambda Expression
			int x=888;
			System.out.println(x);//OutPut::888
			System.out.println(this.x);//OutPut::777 ::�this� keyword represents current outer class object reference 			
		};
		i.m1();
		}
	
	public static void main(String[] args)
	{
		InstanceLocalVariableDemo instanceLocalVariableDemo=new InstanceLocalVariableDemo();
		instanceLocalVariableDemo.m2();
	}
	}


