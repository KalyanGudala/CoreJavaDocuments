package com.core.java8.features.methodsConstructors.references;

public interface Interface {
	public void m1(int i);
}
