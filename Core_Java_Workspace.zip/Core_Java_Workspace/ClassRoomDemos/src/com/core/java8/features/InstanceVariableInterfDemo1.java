package com.core.java8.features;

public class InstanceVariableInterfDemo1 implements InstanceVariableInterf {

	int x = 10;

	public void m1() {
		int y = 20;
		InstanceVariableInterf instanceVariableInterf = () -> {
			System.out.println(x); // 10
		    //System.out.println(y); //20
			x = 888;
			//y = 999; //CE
		};
		instanceVariableInterf.m1();
		y = 777;
	}

	public static void main(String[] args) {
		InstanceVariableInterfDemo1 t = new InstanceVariableInterfDemo1();
		t.m1();
	}

}
