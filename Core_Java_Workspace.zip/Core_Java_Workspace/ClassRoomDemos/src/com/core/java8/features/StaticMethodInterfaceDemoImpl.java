package com.core.java8.features;

/**
 * Static methods inside interface:
   From 1.8version onwards in addition to default methods we can write static methods also inside
   interface to define utility functions.
 *Interface static methods by-default not available to the implementation classes hence by using
   implementation class reference we can�t call interface static
   methods.we should call interface static methods by using interface name.
 * 
 *
 */

public class StaticMethodInterfaceDemoImpl implements StaticMethodInterfaceDemo{
	
	public static void main(String[] args) {
		
		StaticMethodInterfaceDemoImpl staticMethodInterfaceDemoImpl=new StaticMethodInterfaceDemoImpl();
		//staticMethodInterfaceDemoImpl.sum(10,20); CompileTimeError
		//StaticMethodInterfaceDemoImpl.sum(10,20); CompileTimeError
		StaticMethodInterfaceDemo.sum(10, 20);
	}

}
