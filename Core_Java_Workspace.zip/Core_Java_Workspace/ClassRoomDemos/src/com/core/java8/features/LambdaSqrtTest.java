package com.core.java8.features;

public class LambdaSqrtTest {
	public static void main(String[] args)

	{
		SqrtInterf sqrtInterf=x->x*x;
		System.out.println("The Square of 7 is ::"+sqrtInterf.sqrt(7));
		
	}
}
