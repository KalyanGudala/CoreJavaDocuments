package com.core.java8.features;

public interface Interface {
	public void m1();

}
