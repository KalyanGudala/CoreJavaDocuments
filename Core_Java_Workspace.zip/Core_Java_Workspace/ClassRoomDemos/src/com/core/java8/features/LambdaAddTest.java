package com.core.java8.features;

public class LambdaAddTest {
	public static void main(String[] args)
	{
		AddInterf addInterf=(a,b)->System.out.println("The value of LambdaAdd Test is>>>::"+(a+b));
		addInterf.add(2, 5);
	}

}
