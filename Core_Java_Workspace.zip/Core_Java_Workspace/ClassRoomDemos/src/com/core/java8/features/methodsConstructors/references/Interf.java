package com.core.java8.features.methodsConstructors.references;

public interface Interf {
	public Sample get(String s);
}
