package com.core.java8.features.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * If we want to create a separate new object, for every object present in the collection 
 * based on our requirement then we should go for map () method of Stream interface.
 *
 *
 */

public class MapDemo {
	
	public static void main(String[] args) {
		ArrayList<String> l = new ArrayList<String>();
		l.add("rvk"); l.add("rk"); l.add("rkv"); l.add("rvki"); l.add("rvkir");
		System.out.println(l);
		List<String> l2 = l.stream().map(s ->s.toUpperCase()).collect(Collectors.toList());
		System.out.println(l2);
		long count=l2.stream().filter(s ->s.length()==2).count();
		System.out.println("the number of 2 length strings is:"+count);
		List<String> l3=l2.stream().sorted().collect(Collectors.toList());
		System.out.println("according to default natural sorting order:"+l3);
		List<String> l4=l2.stream().sorted((s1,s2) -> -s1.compareTo(s2)).collect(Collectors.toList());
		System.out.println("according to customized sorting order:"+l4);
		String min=l2.stream().min((s1,s2) -> s1.compareTo(s2)).get();
		System.out.println("minimum value is:"+min);
		String max=l2.stream().max((s1,s2) -> s1.compareTo(s2)).get();
		System.out.println("maximum value is:"+max);
	}

}
