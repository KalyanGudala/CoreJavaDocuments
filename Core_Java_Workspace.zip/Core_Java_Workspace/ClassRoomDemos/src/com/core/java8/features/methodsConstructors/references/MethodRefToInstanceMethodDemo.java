package com.core.java8.features.methodsConstructors.references;

public class MethodRefToInstanceMethodDemo {

	public void m2(int i) {
		System.out.println("From Method Reference:"+i);
		
	}
	
	public static void main(String[] args) {
		Interface f = i ->System.out.println("From Lambda Expression:"+i);
		f.m1(10);
		MethodRefToInstanceMethodDemo methodRefToInstanceMethod=new MethodRefToInstanceMethodDemo();
		Interface i1=methodRefToInstanceMethod::m2;
		i1.m1(20);
	}
}
