package com.core.java8.features;

public interface StaticMethodInterfaceDemo {
	public static void sum(int a, int b) {
		System.out.println("The Sum:"+(a+b));
	}
}
