package com.core.java8.features;

public interface Interf {
	public void methodone();

}
