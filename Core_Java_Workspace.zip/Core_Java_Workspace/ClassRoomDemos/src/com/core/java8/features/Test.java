package com.core.java8.features;

 class Demo implements Interf
 {
		 public void methodone()
	 {
		 System.out.println("Sample Demo");
	 }

   }
 

public class Test {
	
	public static void main (String[] args)
	{
		Interf i=new Demo();
		i.methodone();
		
	}

}
