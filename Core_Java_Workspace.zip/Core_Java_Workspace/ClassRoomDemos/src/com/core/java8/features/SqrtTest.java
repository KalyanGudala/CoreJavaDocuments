package com.core.java8.features;

class SqrtDemo implements SqrtInterf {

	public int sqrt(int x) {
		System.out.println("Sqrt of the value is::" + (x * x));
		return x;
	}

}

public class SqrtTest {

	public static void main(String[] args) {
		SqrtInterf sqrtInterf = new SqrtDemo();
		sqrtInterf.sqrt(5);
	}

}
