package com.core.java8.features;

public class InstanceVariableInterfDemo implements InstanceVariableInterf{
	int x = 777;
	public void m1() {		
		InstanceVariableInterf instanceVariableInterf= ()-> {
		int x = 888;
		System.out.println(x); //888
		System.out.println(this.x);// 777
		};
		
		instanceVariableInterf.m1();
		
	}
	public static void main(String[] args)
	{
		InstanceVariableInterfDemo i=new InstanceVariableInterfDemo();
		i.m1();
	}
	}
		


	