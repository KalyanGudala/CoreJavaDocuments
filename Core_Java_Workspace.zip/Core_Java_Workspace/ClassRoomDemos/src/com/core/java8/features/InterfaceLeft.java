package com.core.java8.features;

public interface InterfaceLeft {
	default void m1() {	
		System.out.println("Left Default Method");
	}
	
}
