package com.core.java8.features.methodsConstructors.references;

public class WithLambdaExpression {
	public static void main(String[] args) {
		Runnable r = () -> {
			for (int i = 0; i <= 10; i++) {
				System.out.println("Child Thread");
			}
		};
		Thread t = new Thread(r);
		t.start();
		for (int i = 0; i <= 10; i++) {
			System.out.println("Main Thread");
		}
	}
}
