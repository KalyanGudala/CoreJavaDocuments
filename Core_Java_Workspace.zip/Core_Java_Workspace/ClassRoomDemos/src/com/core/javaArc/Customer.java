package com.core.javaArc;

public class Customer 
{
	
}