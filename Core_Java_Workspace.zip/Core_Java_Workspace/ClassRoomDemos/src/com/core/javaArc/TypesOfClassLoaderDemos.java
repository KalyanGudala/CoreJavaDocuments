package com.core.javaArc;

public class TypesOfClassLoaderDemos {
	public static void main(String[] args)
	{
		System.out.println(String.class.getClassLoader());//null
		System.out.println(SampleDemo1.class.getClassLoader());//Application
		System.out.println(Customer.class.getClassLoader());//Extension
	}

}
