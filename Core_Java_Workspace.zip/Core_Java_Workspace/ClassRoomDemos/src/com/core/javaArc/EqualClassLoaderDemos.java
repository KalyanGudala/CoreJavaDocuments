package com.core.javaArc;

public class EqualClassLoaderDemos {
	
	public static void main(String[]args)
	{
		Student s1=new Student();
		Class c1=s1.getClass();
		Student s2=new Student();
		Class c2=s2.getClass();

        System.out.println(c1.hashCode());
        System.out.println(c2.hashCode());

  if(c1==c2)
		{
		  System.out.println("Same .class file is loaded...");
		}

	}

}
