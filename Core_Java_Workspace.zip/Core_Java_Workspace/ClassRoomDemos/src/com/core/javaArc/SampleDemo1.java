package com.core.javaArc;

public class SampleDemo1 {
	static public void main(String... args) 
	{
		System.out.println("Hello World!");
	}  

}
