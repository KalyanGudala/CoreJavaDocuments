package com.core.javaArc;

import java.lang.reflect.*;
class  Student
{
	private String studentName;  //Fields
	

	public String getstudentName(){

		return studentName;
	}

	public void setstudentName(String studentName)
	{
		this.studentName=studentName;

  }
}

public class ClassLoaderDemo
{
	@SuppressWarnings("rawtypes")
	public static void main(String[] args)throws Exception
	{
		Class c=Class.forName("com.core.javaArc.Student");

		Method[] m1=c.getDeclaredMethods();// To show the List of Methods declared in the class

		 for(Method m: m1)

		{
			System.out.println("Method is..."+m);
		}
     
	  Field[] f1=c.getDeclaredFields();//To show the list of Fields declared in the Class

	  for(Field f:f1)
		{
		    System.out.println("Field is...:"+f);
		 }
}

}
