import java.io.*;
import java.lang.reflect.*;
class  Student
{
	private String studentName;  //Fields
	

	public String getstudentName(){

		return studentName;
	}

	public void setstudentName(String studentName)
	{
		this.studentName=studentName;

  }
}

public class ClassLoaderSubSysDemo
{
	public static void main(String[] args)throws Exception
	{
		Class c1=Class.forName("Student");

		Method[] m1=c1.getDeclaredMethods();// To show the List of Methods declared in the class

		 for(Method m: m1)

		{
			System.out.println("Method is..."+m);
		}
     
	  Field[] f1=c1.getDeclaredFields();//To show the list of Fields declared in the Class

	  for(Field f:f1)
		{
		    System.out.println("Field is...:"+f);
		 }
}

}
