import java.io.*;
import java.lang.ClassLoader;

class TypesOfClassLoaderDemos 
{
	public static void main(String[] args)
	{
		System.out.println(String.class.getClassLoader());//null
		System.out.println(SampleDemo1.class.getClassLoader());//Application
		System.out.println(Customer1.class.getClassLoader());//Extension
	}
}