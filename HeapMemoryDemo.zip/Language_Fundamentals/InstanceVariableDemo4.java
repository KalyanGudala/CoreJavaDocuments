import java.io.*;
class InstanceVariableDemo4
{
	public static void main(String[] args){
		int i=0;
		for(int j=0;j<3;j++){
			j=j+i;
			System.out.println(i+"-----"+j);
		}
		//System.out.println(i+"-----"+j);
	}
}