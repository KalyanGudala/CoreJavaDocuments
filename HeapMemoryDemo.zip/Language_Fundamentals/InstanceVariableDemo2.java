import java.io.*;
class InstanceVariableDemo2
{
	
	 int x; //Instance Variable 
	 double d;//Instance Variable 
	 boolean b;//Instance Variable 
	 String s;//Instance Variable 
	 public static void main(String[] args)
	 {
		 
		 InstanceVariableDemo2 instanceVariable=new InstanceVariableDemo2();
		 System.out.println(instanceVariable.x);
		 System.out.println(instanceVariable.d);
		 System.out.println(instanceVariable.b);
		 System.out.println(instanceVariable.s);
	 }
	 	 	 
}