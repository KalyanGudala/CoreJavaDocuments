import java.io.*;
class StaticVariableDemo1
{
	static int x=10;
	public static void main(String[] args)
	{
		System.out.println(StaticVariableDemo1.x);
		StaticVariableDemo1 staticVariableDemo=new StaticVariableDemo1();
		System.out.println(staticVariableDemo.x);
		System.out.println(x);
	}
}