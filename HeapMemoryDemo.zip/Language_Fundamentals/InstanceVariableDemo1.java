import java.io.*;
class InstanceVariableDemo1
{
	
	 int x=10; //Instance Variable 
	 public static void main(String[] args)
	 {
		 //System.out.println(x);
		 InstanceVariableDemo1 instanceVariable=new InstanceVariableDemo1();
		 System.out.println(instanceVariable.x);
	 }
	 public void m()
	 {
		 System.out.println(x);
	 }
	 	 
}