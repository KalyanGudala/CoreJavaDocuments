import java.io.*;
class VarArgDemo1
{
	public static void m1(int... x)
	{
		System.out.println("Var-Arg method::"+x.length);
	}
	
	public static void main(String[] args){
		m1();
		m1(10);
		m1(10,20,30);
	}
}