import java.io.*;
class InstanceVariableDemo5
{
	public static void main(String[] args)
	{
		int x;
		if(args.length>0)
		{
			x=10;
		}
		
		else{
			x=20;
		}
			System.out.println(x);
	}
}