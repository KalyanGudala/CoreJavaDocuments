import java.io.*;
class InstanceVariableDemo3
{
	public static void main(String[] args)
	{
		int x; //Instance Variable;
		System.out.println(x);
		
	}
}