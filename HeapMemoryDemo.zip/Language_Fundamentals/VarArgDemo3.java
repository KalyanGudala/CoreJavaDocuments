import java.io.*;
class VarArgDemo3
{
	public static void m1(int... x)
	{
		System.out.println("Var-arg method::");	
	}
	
	public static void m1(int x)
	{
		System.out.println("General method::");
	}
	
	public static void m1()
	{
		System.out.println("General method::");
	}
	
	public static void main(String[] args)
	{
		m1();//Var-rag
		m1(10,20);//Var-arg
		m1(30);//General Method
	}
}