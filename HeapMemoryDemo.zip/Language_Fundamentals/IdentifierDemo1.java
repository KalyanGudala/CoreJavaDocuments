import java.io.*;
import java.lang.*;

public class IdentifierDemo1

{

  public static void main(String[] args)

  {

    int String=888;
   
    int Runnable=999;
   
    System.out.println(String);

    System.out.println(Runnable);

   }

}

