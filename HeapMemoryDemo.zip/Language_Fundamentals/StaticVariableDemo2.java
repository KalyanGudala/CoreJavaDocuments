import java.io.*;
class StaticVariableDemo2
{
	static int x=10;
	int y=20;
	public static void main(String[] args)
	{
		StaticVariableDemo2 staticVariableDemo2=new StaticVariableDemo2();
		
		staticVariableDemo2.x=888;
		staticVariableDemo2.y=999;
		
		System.out.println(staticVariableDemo2.x+"_____"+staticVariableDemo2.y);
		
		StaticVariableDemo2 staticVariableDemo22=new StaticVariableDemo2();
		
		System.out.println(staticVariableDemo22.x+"_____"+staticVariableDemo22.y);
		
	}
}