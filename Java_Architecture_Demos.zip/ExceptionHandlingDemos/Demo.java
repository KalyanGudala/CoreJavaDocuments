import java.io.*;

class Demo

{

  public static void main(String[] args)

  {

    try

     {

        System.out.println("Hi");

        //System.out.println(10/0);
       
       System.exit(0);

      }

      

      catch(Exception e)

     { 
     
       e.printStackTrace();

 
      }

    finally
   {
      
     System.out.println("Hi Sunny in finally Block..!!");

   }

  }


}

    