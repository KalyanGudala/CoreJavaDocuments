import java.io.*;

 class ExceptionThrowDemo6

 {

    public static void main(String[] args)

  {

     throw new ExceptionThrowDemo6();
   }

}
