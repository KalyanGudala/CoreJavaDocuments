import java.io.*;
class ExcpetionDemo1

{

public static void main(String[] args)

{

   System.out.println("Hello");

   try{

    System.out.println(10/0);
    

    }
    
      catch(ArithmeticException ae)

{

   System.out.println("Division By Zero");
}

   
   System.out.println("Hi Sunny");

  }

}
