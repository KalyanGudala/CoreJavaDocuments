import java.io.*;

class TryWithResources

{

   public static void main(String[] args) throws Exception

  {

    try(BufferedReader br=new BufferedReader(new FileReader("abc.txt")))

    {
      
      // br=new BufferedReader(new FileReader("output.txt"));

     }

  }
}