import java.io.*;

 class ExceptionThrowDemo4

 {

    public static void main(String[] args)

  {

    System.out.println(10/0);

    System.out.println("Hello");

   }

}
