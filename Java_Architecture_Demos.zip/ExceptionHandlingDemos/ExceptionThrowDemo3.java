import java.io.*;

class ExceptionThrowDemo3

 {
     static ArithmeticException e ;
    
    public static void main(String[] args)

   {

      throw e;

     }

 }
