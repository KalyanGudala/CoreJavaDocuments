import java.io.*;
import java.lang.*;

class MultipleTryCatchDemo

{

    public static void main(String[] args)

 {

    try

  {
      System.out.println("Hi");

      System.out.println(10/0);
     
      String s=null;

      System.out.println(s.length());

      System.out.println("Hello");


  }

 catch(ArithmeticException ae)

 {

    ae.printStackTrace();


  }

catch(NullPointerException npe)

{

        npe.printStackTrace();

    }

  }

}
 