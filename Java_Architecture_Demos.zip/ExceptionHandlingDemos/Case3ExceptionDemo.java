import java.io.*;

class Case3ExceptionDemo

{

  public static void main(String[] args)

 {

   try
    
   {

     System.out.println("Hello");

    }
  
  catch(ArithmeticException e)

 {

    e.printStackTrace();

     }


 }

}



    