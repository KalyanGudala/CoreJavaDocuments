import java.io.*;

 class ExceptionThrowDemo7 extends RuntimeException

 {

    public static void main(String[] args)

  {

     throw new ExceptionThrowDemo7();
   }

}
