import java.io.*;

class Case1ExceptionDemo

{

  public static void main(String[] args)

  
{
   throw new Exception();

  }

}