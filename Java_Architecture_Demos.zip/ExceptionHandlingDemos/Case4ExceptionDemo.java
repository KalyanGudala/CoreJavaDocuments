import java.io.*;

class Case4ExceptionDemo

{

  public static void main(String[] args)

 {

   try
    
   {

     System.out.println("Hello");

    }
  
  catch(Exception e)

 {

    e.printStackTrace();

     }


 }

}



    