import java.io.*;

class GracefulTerminationDemo

{

   public static void main(String[] args)

   {

      System.out.println(" Hello...Sunny");

      try{

      System.out.println(10/0);
    
       }

      catch(ArithmeticException e)
  
     {
        System.out.println("ArithmeticException divison by zero");
       
       }


      System.out.println("Hello... Kalyan");

    }
}
