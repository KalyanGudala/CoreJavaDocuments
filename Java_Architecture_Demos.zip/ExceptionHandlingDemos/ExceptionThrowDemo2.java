import java.io.*;

class ExceptionThrowDemo2

 {
     static ArithmeticException e = new ArithmeticException();
    
    public static void main(String[] args)

   {

      throw e;

     }

 }
