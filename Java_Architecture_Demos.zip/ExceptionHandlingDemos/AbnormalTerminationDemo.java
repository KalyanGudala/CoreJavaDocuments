import java.io.*;

class AbNormalTerminationDemo

{

   public static void main(String[] args)

   {

      System.out.println(" Hello...Sunny");

      System.out.println(10/0);

      System.out.println("Hello... Kalyan");

    }
}
