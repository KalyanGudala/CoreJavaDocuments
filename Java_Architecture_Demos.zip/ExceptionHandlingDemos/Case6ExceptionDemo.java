import java.io.*;

class Case6ExceptionDemo

{

  public static void main(String[] args)

 {

   try
    
   {

     System.out.println("Hello");

    }
  
  catch(InterruptedException e)

 {

    e.printStackTrace();

     }


 }

}



    