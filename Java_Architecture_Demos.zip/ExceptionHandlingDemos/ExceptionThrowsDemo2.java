import java.io.*;
import java.lang.*;

class ExceptionThrowsDemo2

 {

    public static void main(String[] args)throws InterruptedException

  {

    

     Thread.sleep(10000);

    }

}

