import java.io.*;

class Case5ExceptionDemo

{

  public static void main(String[] args)

 {

   try
    
   {

     System.out.println("Hello");

    }
  
  catch(IOException e)

 {

    e.printStackTrace();

     }


 }

}



    