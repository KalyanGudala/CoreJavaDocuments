import java.io.*;

class Case2ExceptionDemo

{

  public static void main(String[] args)

  
{
   throw new Error();

  }

}