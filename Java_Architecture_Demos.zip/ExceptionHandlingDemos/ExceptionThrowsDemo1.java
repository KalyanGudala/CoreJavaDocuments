import java.io.*;

class ExceptionThrowsDemo1

 {

    public static void main(String[] args)throws 

  {

    PrintWriter pw=new PrintWriter("abc1.txt");

     pw.println("Hello");

    }

}

