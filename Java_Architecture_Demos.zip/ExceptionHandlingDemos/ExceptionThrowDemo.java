import java.io.*;

class ExceptionThrowDemo

 {

    public static void main(String[] args)

   {

     throw new ArithmeticException("/by zero");

     }

 }
