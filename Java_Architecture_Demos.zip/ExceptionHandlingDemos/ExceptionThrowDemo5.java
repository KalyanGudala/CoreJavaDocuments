import java.io.*;

 class ExceptionThrowDemo5

 {

    public static void main(String[] args)

  {

    throw new ArithmeticException("/by zero");

    System.out.println("Hello");

   }

}
