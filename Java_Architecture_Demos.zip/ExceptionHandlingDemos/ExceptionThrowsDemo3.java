import java.io.*;
import java.lang.*;

class ExceptionThrowsDemo3

 {

    public static void main(String[] args)

  {

    try{

     Thread.sleep(10000);

    }

   catch(InterruptedException e)

   {
      e.printStackTrace();
      
      }


   }

}
