import java.io.*;

class TestDemo

{

  public static void main(String[] args)

   {

      try
   
      {

        System.out.println(10/0);

        String s=null;
       
        System.out.println(s.length());

       }

catch(Exception e)


    {

      e.printStackTrace();

     }


     
catch(ArithmeticException ae)

   {

      ae.printStackTrace();

    }



   
  }

}