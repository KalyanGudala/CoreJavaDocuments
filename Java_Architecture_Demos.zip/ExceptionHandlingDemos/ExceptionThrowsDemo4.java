import java.io.*;
import java.lang.*;

class ExceptionThrowsDemo4

 {

    public static void main(String[] args)

  {
    
     Thread.sleep(10000);

   }

}
