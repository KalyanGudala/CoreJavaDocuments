import java.io.*;

class P
{

   
  public void m1()
{
  System.out.println("In Parent class P ");
  }

}

class C extends P

{
   public void m2()
{
 
  System.out.println("In Child Class C");
  }
  
}

class InhertianceDemo1
{

   public static void main(String[] args)

   {
        P p=new P();

          p.m1();
          
          //p.m2();

        C c=new C();
     
         c.m1();
         c.m2();

        P p1=new C();
     
          p1.m1();
          //p1.m2();

       //C c1=new P();

   }
}
  

  