import java.io.*;

class ConstructorDemo2

{

  static int count=0;


ConstructorDemo2()

{
   count++;
  }

ConstructorDemo2(int i)

{
    count++;
  }

ConstructorDemo2(double d)

{
    count ++;
  }

public static void main(String[] args)

{
   
  ConstructorDemo2 demo1=new ConstructorDemo2();

  ConstructorDemo2 demo2=new ConstructorDemo2(10);

  ConstructorDemo2 demo3=new ConstructorDemo2(10.5);

 System.out.println("The No of Objects Created for class ConstructorDemo2 is::"+count);

 }

}
