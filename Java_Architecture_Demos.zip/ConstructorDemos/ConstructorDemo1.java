import java.io.*;

class ConstructorDemo1

{

  static int count=0;

{

  count++;

 }

ConstructorDemo1()

{
   
  }

ConstructorDemo1(int i)

{
    
  }

ConstructorDemo1(double d)

{
    
  }

public static void main(String[] args)

{
   
  ConstructorDemo1 demo1=new ConstructorDemo1();

  ConstructorDemo1 demo2=new ConstructorDemo1(10);

  ConstructorDemo1 demo3=new ConstructorDemo1(10.5);

 System.out.println("The No of Objects Created for class ConstructorDemo1 is::"+count);

 }

}
