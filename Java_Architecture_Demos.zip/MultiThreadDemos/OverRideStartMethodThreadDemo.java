import java.lang.*;

class MyThread extends Thread

{

public void start()

{
   System.out.println("start method...");

 }

public void run()

{
   System.out.println("run...");

 }


   
}

class OverRideStartMethodThreadDemo

{

   public static void main(String[] args)

  {

     MyThread t= new MyThread();

              t.start(); // start of a child Thread

              //t.run();

   }
}
