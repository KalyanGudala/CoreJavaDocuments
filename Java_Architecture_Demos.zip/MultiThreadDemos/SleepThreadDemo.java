
import java.io.*;
import java.lang.*;

class SleepThreadDemo

{

   public static void main(String[] args)throws InterruptedException

  {

     System.out.println("Kalyan");

     Thread.sleep(5000);

     System.out.println("Gudala");

     Thread.sleep(5000);
}

}
