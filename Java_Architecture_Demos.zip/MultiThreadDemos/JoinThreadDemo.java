import java.io.*;
import java.lang.*;

class MyThread extends Thread

{

   public void run()

  {

     for(int i=0; i<=10;i++)

    {
      
      
      System.out.println("Child Thread...");


     }

  }

}

class JoinThreadDemo

{

   public static void main(String[] args)throws InterruptedException

  {

     MyThread t= new MyThread();
   
    t.join();
         
    t.start(); // start of a child Thread

   for(int i=0;i<=10;i++)

 {

    System.out.println("Main Thread...");

      }

  }

}
