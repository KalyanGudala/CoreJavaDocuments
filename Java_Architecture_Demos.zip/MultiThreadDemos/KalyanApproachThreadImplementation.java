import java.lang.*;

class KalyanThread extends Thread

{

   public void run()

  {

     
      System.out.println("run Thread...");


  }

}

class KalyanApproachThreadImplementation

{

   public static void main(String[] args)

  {

     KalyanThread t= new KalyanThread ();


     Thread  t1=new Thread(t);

              t1.start(); // start of a child Thread

   
    System.out.println("Main Thread...");

      

  }

}
