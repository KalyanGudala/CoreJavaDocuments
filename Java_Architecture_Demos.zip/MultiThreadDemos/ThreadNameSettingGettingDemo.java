
import java.lang.*;

class ThreadNameSettingGettingDemo

{

   public static void main(String[] args)

  {

     System.out.println(Thread.currentThread().getName());// Main

     Thread.currentThread().setName("Kalyan");

     System.out.println(Thread.currentThread().getName());// Kalyan
   }
}
