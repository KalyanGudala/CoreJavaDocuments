import java.lang.*;

class MyThread extends Thread

{

public void run()

{
   System.out.println("run()");

 }

public void run(int i)

{
   System.out.println("run(int i)");

 }


   
}

class OverLoadedRunMethodThreadDemo

{

   public static void main(String[] args)

  {

     MyThread t= new MyThread();

              t.start(); // start of a child Thread

   }
}
