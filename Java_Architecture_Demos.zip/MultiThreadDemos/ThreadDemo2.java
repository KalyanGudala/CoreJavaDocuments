import java.lang.*;

class MyThread extends Thread

{

   
}

class ThreadDemo2

{

   public static void main(String[] args)

  {

     MyThread t= new MyThread();

              t.start(); // start of a child Thread

   }
}
