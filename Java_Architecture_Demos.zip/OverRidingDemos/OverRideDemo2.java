import java.io.*;
class Parent

{

  public void m1(int... x)

 {
    System.out.println("Parent Var-arg method");
   
  }

}

class Child extends Parent

{

  public void m1(int x)

 {
    System.out.println("child method"); 

   }

}

public class OverRideDemo2

{

  public static void main(String[] args)

 {

   Parent p=new Parent();
   
     p.m1(10);

   Child c=new Child ();

    c.m1(10);

  
   Parent p1=new Child();

     p1.m1(10);

  }

}