import java.io.*;

class Parent
{
  int x=888;

}

class Child extends Parent

{

  int x=999;

 }

class OverRideDemo3

{

  public static void main(String[] args)

 {

   Parent p=new Parent();
 
    System.out.println(p.x);

   Child c=new Child();

   System.out.println(c.x);
 
  Parent p1=new Child();
 
  System.out.println(p1.x);

  }

}


