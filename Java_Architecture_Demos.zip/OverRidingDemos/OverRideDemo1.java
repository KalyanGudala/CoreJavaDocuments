import java.io.*;

class Parent

{

   public void property()

  {
     System.out.println("Ca$h+Land+Gold");

   }

  public void marry()

 {

  System.out.println("Subba Laxmi");

  }

 }


class Child extends Parent

{

   public void marry()

  {

   System.out.println("Marry 3$Ha,9Tara,4Me");

   }

}

class OverRideDemo1

{

   public static void main(String[] args)

  {

    Parent p=new Parent();

      p.marry(); ///parent Method
    
   Child c=new Child();

     c.marry();/// child Method

  Parent p1=new Child();

    p1.marry();/// Child Method

  }

}

 