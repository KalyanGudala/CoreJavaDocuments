import java.io.*;

class OverLoadedTest
{

  public void m1(int i)

{
  System.out.println("int-arg Method");

 }

public void m1(float f)

{

  System.out.println("float-arg method");

 }

}

class OveroLoadDemo2

{

 public static void main(String[] args)

 {

   OverLoadedTest test=new OverLoadedTest();
  
    test.m1(10);

    test.m1(10.5f);

    test.m1('a');
   
    test.m1(10l);

    //test.m1(10.5);

    

   }
}

    
   

  

  