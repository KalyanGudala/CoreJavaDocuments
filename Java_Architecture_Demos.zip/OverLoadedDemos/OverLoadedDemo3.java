
import java.io.*;
import java.lang.*;

class OverLoadedTest
{

  public void m1(String s)

 {

  System.out.println("String Version");

  }

  public void m1(Object s)

 {

   System.out.println("Object Version");
 
  }

}

public class OverLoadedDemo3

{

  public static void main(String[]args)
{
   OverLoadedTest test=new OverLoadedTest();

    
   test.m1("Kalyan");

   test.m1(new Object());

   test.m1(null);

   }

}



  
