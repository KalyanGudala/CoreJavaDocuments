import java.io.*;

class OverlOadedTest
{

  public void m1()
{

   System.out.println("No-arg method");
 }

public void m1(int i)
{
  System.out.println("int-arg method");

 }
public void m1(double d)
{

  System.out.println("double-arg method");

}

}

class OverLoadedDemo1
{

  public static void main(String[] args)
{

   OverlOadedTest test=new OverlOadedTest();

   test.m1();
   test.m1(2);
   test.m1(2.0);

  }

}

