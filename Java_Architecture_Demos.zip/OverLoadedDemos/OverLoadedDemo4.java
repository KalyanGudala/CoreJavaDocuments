
import java.io.*;
import java.lang.*;

class OverLoadedTest
{

  public void m1(String s)

 {

  System.out.println("String Version");

  }

  public void m1(StringBuffer s)

 {

   System.out.println("StringBuffer Version");
 
  }

}

public class OverLoadedDemo4

{

  public static void main(String[]args)
{
   OverLoadedTest test=new OverLoadedTest();

    
   test.m1("Kalyan");

   test.m1(new StringBuffer("Sunny"));

   test.m1(null);

   }

}



  
