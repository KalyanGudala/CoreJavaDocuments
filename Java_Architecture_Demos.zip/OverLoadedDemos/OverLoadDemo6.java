import java.io.*;

class Animal 

{

   }

class Monkey extends Animal

{

  }

class OverloadTest

{

  public void m1(Animal a)

  {

     System.out.println("Animal Version");

   }

   public void m1(Monkey m)

   {

      System.out.println("Monkey Version");
 
      }

}

public class OverLoadDemo6

{

  public static void main(String[] args)

 {

     OverloadTest test=new OverloadTest();

     Animal a =new Animal();

     test.m1(a);

     Monkey m=new Monkey();

     test.m1(m);

     Animal a1 = new Monkey();

     test.m1(a1);

     //Monkey m1=new Animal();
     
     //test.m1(m1);
 

   }

}
