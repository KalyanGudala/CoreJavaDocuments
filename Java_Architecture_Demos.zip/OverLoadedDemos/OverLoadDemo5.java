import java.io.*;

class OverLoadedTest
{

  public void m1(int x)

 {

   System.out.println("General Method");

   
   }

public void m1(int... x)

{

  System.out.println("Var-arg Methods");

 }

public void m1()
{
   System.out.println("No-arg Methods");

}

}

public class OverLoadDemo5

{

  public static void main(String[] args)

{

   OverLoadedTest test=new OverLoadedTest();

    test.m1(); // var-arg Method

    test.m1(10);//General Method

    test.m1(10,20);// Var-arg Method

  }

}