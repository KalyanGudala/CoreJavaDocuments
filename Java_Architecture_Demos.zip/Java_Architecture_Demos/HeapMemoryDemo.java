import java.io.*;
import java.lang.*;
class HeapMemoryDemo 
{
	public static void main(String[] args)throws Exception 
	{
		
		long mb=1024*1024;
		Runtime r=Runtime.getRuntime();
		System.out.println("Maximum Memory:"+r.maxMemory()/mb);
		System.out.println("Total Memory:"+r.totalMemory()/mb);
		System.out.println("FreeMemory:"+r.freeMemory()/mb);

	}
}
