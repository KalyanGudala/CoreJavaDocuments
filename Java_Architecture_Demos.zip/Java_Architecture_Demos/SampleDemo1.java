import java.io.*;
class SampleDemo1 
{
	static public void main(String... args) 
	{
		System.out.println("Hello World!");
	}                                  
}
