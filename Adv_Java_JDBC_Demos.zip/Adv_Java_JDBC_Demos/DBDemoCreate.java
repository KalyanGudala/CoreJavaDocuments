import java.io.*;
import java.sql.*;
import java.util.*;

public class DBDemoCreate
{
  public static void main (String[] args)throws Exception
  {
	  String driverClass="oracle.jdbc.driver.OracleDriver";				
      String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
	  Class.forName(driverClass);
	  Connection conn=DriverManager.getConnection(url);
	  System.out.println("Connection Established");
	  Statement stm=conn.createStatement();
	  String dropCommand="DROP TABLE emp";
	  String createCommand="CREATE TABLE emp"+"("+"EmpNo int primary key,"+"EmpName varchar(20),"+"sal float"+")";
	  
	  try
	  {
		 stm.execute(dropCommand);
		 System.out.println("Emp TABLE Dropped...Successfully");
	  }
	  catch(SQLException sqe)
	  {
		  sqe.printStackTrace();
		  System.out.println("Ignore If Table doesn't Exisst");
	  }
	  
	    stm.execute(createCommand);
		System.out.println("Emp TABLE Created...Successfully");
        stm.close();
		conn.close();
	  }
}