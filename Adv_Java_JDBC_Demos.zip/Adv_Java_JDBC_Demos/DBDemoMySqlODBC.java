import java.io.*;
import java.sql.*;

public class DBDemoMySqlODBC
{
	
	public static void main(String[] args)throws Exception
	{
		
		String driverClass="com.mysql.jdbc.Driver";				
        //String url="jdbc:mysql://localhost:3306/mysql","root","password";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","password");
		System.out.println("Connection Established");
		conn.close();
	}

}
	
	