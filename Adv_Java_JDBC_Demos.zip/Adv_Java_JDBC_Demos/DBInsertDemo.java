import java.io.*;
import java.sql.*;
 
public class DBInsertDemo
{
  public static void main(String[] args)throws Exception
  {
	    String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement();
		
		String insertCommand="INSERT INTO EMP VALUES(387145,'NALLAGUNTA SARITHA',80000)";
		
		int count =stm.executeUpdate(insertCommand);
		System.out.println("row(s) inserted"+count);
		stm.close();
		conn.close();
  }
}