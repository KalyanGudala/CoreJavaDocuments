import java.io.*;
import java.sql.*;

public class CreateProcedureDemo
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement();
		
		String createAddNum = "create procedure add_num(a in number ,b in number,c out number) \n AS \n BEGIN \n c:=a+b; \n END add_num;";
		
		stm.execute(createAddNum);
		System.out.println("Procedure add_num Created...!!");
		stm.close();
		conn.close();
	}
}

		
