import java.io.*;
import java.sql.*;

public class UpdateResultSetDemo
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		ResultSet rs=stm.executeQuery("select onum,amt from orders");
		while(rs.next())
		{
			if(rs.getInt(1)==3001)
			{
		       rs.updateInt(2,20);
		       rs.updateRow();
		      System.out.println("1 row effected....");
			}
		}
		//rs.moveToInsertRow();
		rs.close();
		stm.close();
		conn.close();
		
	}
}

		