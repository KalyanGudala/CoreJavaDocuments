import java.io.*;
import java.sql.*;


public class CallableStatementDemo
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		CallableStatement cstm=conn.prepareCall("{call add_num(?,?,?)}");
		cstm.setInt(1,Integer.parseInt(args[0]));
		cstm.setInt(2,Integer.parseInt(args[1]));
		cstm.registerOutParameter(3,Types.INTEGER);
		cstm.execute();
		int result=cstm.getInt(3);
		System.out.println("Sum is:"+result);
		cstm.close();
		conn.close();
		
	}
}
	