import java.io.*;
import java.sql.*;

public class CreateProcedureDemo2
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement();
		
		String createGetSalary="CREATE PROCEDURE get_salary(@empid INT ,@sal FLOAT OUTPUT)"+"AS"+
		                        "SELECT @sal=sal FROM emp WHERE empno=@empid"+"IF(@@rowcount<1)"+"RAISEERROR('No Such Employee',16,1)";
								
								
		stm.execute(createGetSalary);
		System.out.println("Procedure get_salary Created");
		stm.close();
		conn.close();
		
	}
}