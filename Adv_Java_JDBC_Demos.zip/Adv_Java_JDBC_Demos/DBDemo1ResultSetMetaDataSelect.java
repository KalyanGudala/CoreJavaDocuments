import java.io.*;
import java.sql.*;

public class DBDemo1ResultSetMetaDataSelect
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement();
		
		String query="SELECT EMPNO,EMPNAME,SAL FROM EMP";
		
		ResultSet rs =stm.executeQuery(query);
		ResultSetMetaData rmd=rs.getMetaData();
		
		int columns=rmd.getColumnCount();
		System.out.println("No of columns is:::"+columns);
		for(int i=1;i<columns;i++)
		{
			System.out.println(rmd.getColumnName(i)+ "\t");
		}
		
		while(rs.next())
		{
			int empno=rs.getInt(1);
			String ename=rs.getString(2);
			float sal=rs.getFloat(3);
			String salDisplay;
			
			boolean salIsNull=rs.wasNull();
			
			if(salIsNull)
			
		      salDisplay="Null";
			
			else
				salDisplay=String.valueOf(sal);
			    System.out.println(empno +"\t"+ename+"\t"+salDisplay);
			
		}
		rs.close();
		stm.close();
		conn.close();
		
	}
	
}	