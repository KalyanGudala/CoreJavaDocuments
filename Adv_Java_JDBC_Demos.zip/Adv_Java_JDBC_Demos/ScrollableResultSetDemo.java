import java.io.*;
import java.sql.*;

public class ScrollableResultSetDemo
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		ResultSet rs=stm.executeQuery("select * from emp");
		System.out.println("Records in the Table are....");
		while(rs.next())
		{
			System.out.println("EmpId is..."+rs.getInt(1));
			System.out.println("EmpName is..."+rs.getString(2));
			System.out.println("EmpSal is..."+rs.getInt(3));
		}
		rs.first();//It Places the cursor @ the first record..
		System.out.println("First Record...");
		System.out.println("EmpId is..."+rs.getInt(1));
		System.out.println("EmpName is..."+rs.getString(2));
		System.out.println("EmpSal is..."+rs.getInt(3));
		
		rs.absolute(3);//It Places the cursor @ the third record..
		System.out.println("Third Record...");
		System.out.println("EmpId is..."+rs.getInt(1));
		System.out.println("EmpName is..."+rs.getString(2));
		System.out.println("EmpSal is..."+rs.getInt(3));
		
		rs.last();//It Places the cursor @ the last record..
		System.out.println("Last Record...");
		System.out.println("EmpId is..."+rs.getInt(1));
		System.out.println("EmpName is..."+rs.getString(2));
		System.out.println("EmpSal is..."+rs.getInt(3));
		
		rs.previous();
		rs.relative(-1);
		System.out.println("Second Record...");
		System.out.println("EmpId is..."+rs.getInt(1));
		System.out.println("EmpName is..."+rs.getString(2));
		System.out.println("EmpSal is..."+rs.getInt(3));
		
		rs.close();
		stm.close();
		conn.close();
	}
	
}
		
		
		