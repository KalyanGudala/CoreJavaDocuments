import java.io.*;
import java.sql.*;

public class PreparedStatementDemo
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		String insertCommand="INSERT INTO EMP VALUES(?,?,?)";
		PreparedStatement pstm=conn.prepareStatement(insertCommand);
		
		pstm.setInt(1,387146);
		pstm.setString(2,"PRAVEEN");
		pstm.setFloat(3,70000);
		
		int count=pstm.executeUpdate();
		System.out.println("row(s) inserted.."+count);
		
		pstm.setInt(1,387147);
		pstm.setString(2,"SANTHOSH");
		pstm.setFloat(3,50000);
		
		count=pstm.executeUpdate();
		System.out.println("row(s) inserted.."+count);
		
		pstm.close();
		conn.close();
		
	}
}
