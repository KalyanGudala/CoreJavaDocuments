import java.io.*;
import java.sql.*;
 
public class DBCommitDemo
{
  public static void main(String[] args)throws Exception
  {
	    String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement();
		conn.setAutoCommit(false);// Method
		String deleteCommand="DELETE FROM EMP WHERE EMPNO="+args[0];
		int count=stm.executeUpdate(deleteCommand);
		if(count>0)
		System.out.println("Employee Deleted..");
		else
			System.out.println("No Such Employee..");
		conn.rollback();
		System.out.println("Transaction RollBack..");
		conn.setAutoCommit(true);
		stm.close();
		conn.close();
  }
  
}