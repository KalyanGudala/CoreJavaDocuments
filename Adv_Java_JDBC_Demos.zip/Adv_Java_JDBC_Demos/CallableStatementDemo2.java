import java.io.*;
import java.sql.*;


public class CallableStatementDemo2
{
   public static void main(String[] args)throws Exception
    {
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		CallableStatement cstm=conn.prepareCall("{call get_salary(?,?)}");
	    int empno=Integer.parseInt(args[0]);
		cstm.setInt(1,empno);
		cstm.registerOutParameter(2,Types.FLOAT);
		try
		{
			cstm.execute();
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
			return;
		}
		float salary=cstm.getFloat(2);
		if(cstm.wasNull())
			System.out.println("Salry is NULL");
		else
			System.out.println("Salary="+salary);
	}
}