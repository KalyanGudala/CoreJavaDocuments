import java.io.*;
import java.sql.*;

public class DemoUpdate
{
        
	public static void main(String[] args)throws Exception
	 {
			
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		Statement stm=conn.createStatement();
		String updateCommand="UPDATE EMP SET EMPNAME='SANTHOSH' WHERE EMPNO=387147";
		int count =stm.executeUpdate(updateCommand);
		System.out.println("row(s) updated :"+count);
		stm.close();
		conn.close();
		
	 }
}