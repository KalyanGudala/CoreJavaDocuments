import java.io.*;
import java.sql.*;

public class DBDemoODBC
{
	
	public static void main(String[] args)throws Exception
	{
		
		String driverClass="oracle.jdbc.driver.OracleDriver";				
        String url="jdbc:oracle:thin:scott/Tiger@localhost:1521:orcl";		
		Class.forName(driverClass);
		Connection conn=DriverManager.getConnection(url);
		System.out.println("Connection Established");
		conn.close();
	}
}