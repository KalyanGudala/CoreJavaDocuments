package pack2;
import pack1.A;
import java.io.*;
public class B

{

  public static void main(String [] args)
{

    A a=new A();
    a.m1();
   
     }

}



 
