import java.io.*;
import java.lang.Thread;

class GarbageCollectionCase4

{

   static GarbageCollectionCase4 gc2;

   public static void main(String args[])throws Exception
{

      GarbageCollectionCase4 gc1=new GarbageCollectionCase4();
    
       System.out.println(gc1.hashCode());

               gc1=null;

          System.gc();

        Thread.sleep(2000);

    
System.out.println(gc1.hashCode());

   System.gc();

Thread.sleep(5000);

 System.out.println("End Of Main");

}

public void finalize()
{

  System.out.println("Finalize Method");

  gc2=this;

 }

}


   