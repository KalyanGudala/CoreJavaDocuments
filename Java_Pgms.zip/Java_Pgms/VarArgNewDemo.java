import java.io.*;
class VarArgNewDemo
{

  public static void m(int i)
{

  System.out.println("General Method");
}

public static void m1(int...i)
{

  System.out.println("Var-Arg method");
 
 }

public static void main(String[] args)
{

   m1();
   m1(10,20);
   m1(10,20,30);
   m(40);

 }

}