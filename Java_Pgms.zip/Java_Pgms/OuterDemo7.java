import java.io.*;
class OuterDemo7

{

 int x=10;
 public void m1()

{

     int y=10; //If we declare 'y'  with final modifier we wont get any compile time error.
            // Else We will get Compile Time Error saying :local variable 'y 'is accessed from within inner class needs to be declared final..

     //final int y=10;
class Inner

{

   int z=30;

public void Test()

{

  System.out.println(x);
  System.out.println(y);
  System.out.println(z);

          }

       }

    }

}
 


  
  

   