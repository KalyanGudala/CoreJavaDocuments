package pack1;
import java.io.*;


public class A

{

  public static void m1()
{

  System.out.println("Hi Helloo");

  }

}