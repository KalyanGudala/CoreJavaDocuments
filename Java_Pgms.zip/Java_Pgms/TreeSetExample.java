import java.util.Iterator;
import java.util.TreeSet;


public class TreeSetExample{
     public static void main(String [] args){
         TreeSet ts = new TreeSet();
         ts.add("B");
         ts.add("D");
         ts.add("A");
         ts.add("E");
         ts.add("F");
         ts.add("C");
         Iterator it = ts.iterator();
            while (it.hasNext()) {
                System.out.println(it.next());
            }
          System.out.println("Size :" + ts.size());
     }
}
