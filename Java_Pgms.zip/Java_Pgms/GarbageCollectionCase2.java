import java.io.*;
import java.lang.String;

class GarbageCollectionCase2
{

   public static void main(String args[])

{

    GarbageCollectionCase2 t=new GarbageCollectionCase2();

    t=null;

    System.gc();

  System.out.println("END OF MAIN METHOD");

 }

public void finalize()

{

   System.out.println("Finalize Method is called");

 }

}



