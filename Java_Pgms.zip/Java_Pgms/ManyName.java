import java.io.*;
import java.lang.Runnable;
import java.lang.Thread;

class NameRunnable implements Runnable
{
  
   public void run()
{
   for(int x=1; x<=3;x++)
    
   {

       System.out.println("Run By is:"+Thread.currentThread().getName() + ",x is "+x);

         }

    }

}

public class ManyName{

public static void main(String[] args)
{

   NameRunnable nr=new NameRunnable();
   Thread one =new Thread(nr);
   Thread two =new Thread(nr);
   Thread three =new Thread(nr);

   one.setName("Kalyannn");
   two.setName("Sarithaaa");
   three.setName("KKKKKK");
   one.start();
   two.start();
   three.start();
   
    }
}
   