import java.io.*;
public class GarbageCollectionDemo4

{
   
   public static void main(String[] args)

{
   
  GarbageCollectionDemo4 gc =m1();

  System.out.println("Case ii value is::"+gc);
 
   }

  public static GarbageCollectionDemo4 m1()
{

   GarbageCollectionDemo4 gc1=new GarbageCollectionDemo4();
 
    System.out.println("Value of Gc1 is ::"+gc1);

   GarbageCollectionDemo4 gc2=new GarbageCollectionDemo4();

    System.out.println("Value of GC2 is::"+gc2);

     return gc1;   

  }

}

