package pack3;
import java.io.*;
public class C

{

  public void m1()
{

   System.out.println("This is class C with package3");
 }

}