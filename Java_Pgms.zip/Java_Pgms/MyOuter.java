import java.io.*;
class MyOuter
{

  class MyInner
{

   public void sum(int a ,int b)

 {

    

   System.out.println("Sum is:" +(a+b));

   }

 }

 public void m1(int x,int y)
{

   MyInner i=new MyInner();
           i.sum(x,y);

  }

public static void main(String args[])

{

   MyOuter.MyInner i=new MyOuter().new MyInner();
          i.sum(100,200);

    //MyOuter o=new MyOuter();
           // o.m1(10,20);
  

  }

}