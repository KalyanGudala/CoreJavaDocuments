import java.io.*;
class OuterDemo

{

   class Inner
{

   public static void main (String args[])

{

    System.out.println("Helloo");
     
     }

  }

}




 

