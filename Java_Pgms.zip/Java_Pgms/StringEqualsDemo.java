import java.io.*;
import java.lang.String;
class StringEqualsDemo
{

   String name;
   int rollno;

StringEqualsDemo(String name,int rollno)
{

   this.name=name;
   this.rollno=rollno;

  }

public static void main(String[] args)
{
  StringEqualsDemo s1=new StringEqualsDemo("Kalyan",101);
  StringEqualsDemo s2=new StringEqualsDemo("Sarita",102);
  StringEqualsDemo s3=new StringEqualsDemo("Gudala",103);
  StringEqualsDemo s4=new StringEqualsDemo("Gudala",104);
  System.out.println(s1.equals(s2));
  System.out.println(s2.equals(s3));
  System.out.println(s3.equals(s4));

   }

}