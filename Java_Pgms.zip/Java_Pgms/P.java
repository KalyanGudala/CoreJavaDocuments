package pack5;
import java.io.*;

public class P

{

   protected void m1()

{

   System.out.println("Protected Method in Parent Class of Package5");

  }

}

