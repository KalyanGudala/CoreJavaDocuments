import java.io.*;
import java.lang.Runnable;
class AnonynomousDemo2
{

   public static void main(String args[])

 {

    Runnable r=new Runnable()   //Anonymous Inner class that implements Interface

   {

      public void run()

     {

        for(int i=10;i<10;i++)

        {
               System.out.println("Child Thread...");

            }

       }

    };

Thread t=new Thread(r);

       t.start();

for(int i=0;i<10;i++)

{

   System.out.println("Main Thread...");

      }

  }

}