import java.io.*; 
public class GarbageTruck
{
  public static void main(String[] args)
{

   StringBuffer sb=new StringBuffer("Hello");
    System.out.println(sb);
    sb=null;
    System.out.println(sb);

  }
}