import java.io.*;
class NestedClassDemo

{

   static class Inner //Static Nested Class

 {

    public void m1()
  {

     System.out.println("Static class Method");

         }

    }

public static void main(String args[])

{
 
   NestedClassDemo.Inner i=new NestedClassDemo.Inner();

    i.m1();

    }

}


   