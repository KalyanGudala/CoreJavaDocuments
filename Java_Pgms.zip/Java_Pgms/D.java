package pack6;
import pack3.C;
class D

{

  public static void main(String args[])
{
  C c=new C();
     c.m1();

System.out.println("This is class D with package4");

   }

}

