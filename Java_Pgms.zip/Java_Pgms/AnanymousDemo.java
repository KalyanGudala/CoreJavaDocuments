import java.io.*;
class PopCorn
{

   public void taste()
{
   System.out.println("PopCorn is Spicy");

 }

   public void m1()

{

   System.out.println("popcorn m1() method");

  }
}

class AnanymousDemo

{

   public static void main(String args[])

 {

    PopCorn p=new PopCorn()

   {

      public void taste()

     {

         System.out.println("popcorn is tasty");

         }

      };

    p.taste();
    p.m1();

  }

}
