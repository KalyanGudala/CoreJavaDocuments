import java.io.*;


class GarbageCollectionCase3

{

   public static void main(String args[])
{

   GarbageCollectionCase3 t=new GarbageCollectionCase3();

          // t.finalize();
             
           t=null;

        System.gc();

  System.out.println("End Of Main Method");

 }

public void finalize()

{

   System.out.println("Finalize Method");

   try
{

   System.out.println(10/0);

 }catch(ArithmeticException e)
{

  System.out.println("Caught the Arithmetic Exception");

       }

   }

}