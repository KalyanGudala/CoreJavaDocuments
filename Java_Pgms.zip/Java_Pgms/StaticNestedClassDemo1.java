import java.io.*;
class StaticNestedClassDemo1

{

   //int x=10;

   static int y=20;

static class Inner

{

   public void m1()

 {

   // System.out.println(x);
    System.out.println(y);

       }

    }

public static void main(String args[])

{

  new StaticNestedClassDemo1().new Inner().m1();
                               

  }

}

