import java.io.*;
import java.lang.Thread;
import java.lang.Runnable;

class MyRunnable implements Runnable
{

  public void run(){

  System.out.println("Importing job running in MyRunnable");
   
     }

}

public class TestThreads
{

   public static void main(String[] args)
{

   MyRunnable r=new MyRunnable();
   Thread foo=new Thread(r);
   System.out.println("Thread one is:"+foo);
   Thread bar=new Thread(r);
   System.out.println("Thread two is:"+bar);
   Thread bat=new Thread(r);
   System.out.println("Thread three is:"+bat);
   }
}
 