import java.io.*;
class VarArgDemoCase3
{

 public static void m1(Object... i)
{

  System.out.println("Object Method...");

 }

 public static void m1(int... i)
{
  
  System.out.println("Var-arg Method...");

 }

public static void main(String args[])
{
   int i=10;

  m1(i);

 }

}
 