import java.io.*;
class GarbageCollectionDemo5

{

   GarbageCollectionDemo5 i;

public static void main(String args[])

{

  GarbageCollectionDemo5 t1=new GarbageCollectionDemo5();

  System.out.println("Value of GarbageCollectionDemo5 t1 is @@@@::"+t1);

  GarbageCollectionDemo5 t2=new GarbageCollectionDemo5();

  System.out.println("Value of GarbageCollectionDemo5 t2 is #####::"+t2);

  GarbageCollectionDemo5 t3=new GarbageCollectionDemo5();

  System.out.println("Value of GarbageCollectionDemo5 t3 is &&&&::"+t3);

     t1.i=t2;

   System.out.println("Value of GarbageCollectionDemo5 t1 is::"+t1);

     t2.i=t3;

   System.out.println("value of GarbageCollectionDemo5 t2 is:: "+t2);

     t3.i=t1;

   System.out.println("value of GarbageCollectionDemo5 t3 is:: "+t3);

 

     t1=null;

   System.out.println("Value of GarbageCollectionDemo5 t1 is xxxxxx::"+t1);
 
     t2=null;

    System.out.println("Value of GarbageCollectionDemo5 t2 is yyyyyy::"+t2);
 
     t3=null;

    System.out.println("Value of GarbageCollectionDemo5 t3 is zzzzzz::"+t3);


   }

}




   
 

