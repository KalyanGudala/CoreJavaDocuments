import java.io.*;
import java.lang.Thread;
class Display
{
  public synchronized void wish(String name)
 {
   
   for(int i=0;i<5;i++)
 {
   System.out.println("Good Morning:");
 
try
{
  
   Thread.sleep(3000);
 
}
catch(InterruptedException e)
{
  
  System.out.println("Exception caught"); 
 
  }
 
     System.out.println(name);
  }
 }
}
class Mythread extends Thread
{
  Display d;
  String name;

Mythread(Display d,String name)
  
{
  this.d=d;
  this.name=name;
 
  }

 public void run()

{
   d.wish(name);

  }
 }


public class SynchronizedDemo

{
  public static void main(String[] args)
 {
   Display d1=new Display();
   Mythread t1=new Mythread(d1,"M.S.DHONI");
   Mythread t2=new Mythread(d1,"Virat Kohli");
   
   //Display d2=new Display();
   //Mythread t2=new Mythread(d2,"Virat Kohli");

   t1.start();
   t2.start();

   //t1.run();
   //t2.run();
   
 }
}

