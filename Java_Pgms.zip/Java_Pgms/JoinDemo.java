import java.io.*;
import java.lang.Runnable;
import java.lang.Thread;


class MyThread implements Runnable
{

  public void run()
{

try{

   for(int i=0;i<=10;i++)
{
  System.out.println("Sita's Thread");
  Thread.sleep(2000);

  }
}catch(InterruptedException e)
{
   
  }


      }
 
   }


public class JoinDemo{

   public static void main(String[] args)throws InterruptedException 
{

    MyThread mr=new MyThread();
    Thread t=new Thread(mr);

     t.start();
     t.join(6000);
for(int i=0;i<=10;i++)
{

  System.out.println("Rama's Thread");

     }

  }

}