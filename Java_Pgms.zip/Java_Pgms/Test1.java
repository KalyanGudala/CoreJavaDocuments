import java.io.*;
class Test1
{

public static void main(String[] args){

Test1 t1=new Test1();
Test1 t2=new Test1();
if(!t1.equals(t2))
System.out.println("They aren't Equal");
if(t1 instanceof Object)
System.out.println("t1's an object");
  
    }

}