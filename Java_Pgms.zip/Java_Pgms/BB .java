package pack6;
import pack5.P;
import java.io.*;
class BB extends P
{
 public static void main(String[] args)
{
   
   BB b=new BB();

      b.m1();
  
  }
   
}




