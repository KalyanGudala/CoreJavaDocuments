import java.io.*;
class VarArgDemoCase1
{

  public static void m1(byte... b)
{

   System.out.println("Vararg Byte Method...");

 }

 public static void m1(int... i) 

 {
   System.out.println("Vararg Int Method...");

  }

public static void main(String args[])

{

    byte b=10;
    m1(b);

  }

}



