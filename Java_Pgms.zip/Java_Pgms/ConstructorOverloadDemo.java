import java.io.*;
public class ConstructorOverloadDemo
{

   ConstructorOverloadDemo()
{

    this(10);
  System.out.println("No-Args");
 
  }

ConstructorOverloadDemo(int i)
{

   this(10.5);
 System.out.println("int args");

}

ConstructorOverloadDemo(double d)
{

  
  System.out.println("Double Args");

 }

public static void main(String[] args)
{
  ConstructorOverloadDemo c=new ConstructorOverloadDemo();

  System.out.println("No arg value is:"+c);

  ConstructorOverloadDemo c1=new ConstructorOverloadDemo(10); 
   
  System.out.println("Arg int Value is:"+c1); 

  ConstructorOverloadDemo c2=new ConstructorOverloadDemo(10.5);
  
  System.out.println("Arg double value is:"+c2);

 }

}