import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;


 public class SetsExample{
 public static void main(String args[]){
     Set<String> set1 = new HashSet<String>();
     set1.add("B");
     set1.add("A");
     set1.add("C");
     set1.add("A"); //A is a duplicate value
     System.out.println("Set is " + set1);
     set1.remove("C");
     System.out.println("Set1 after removing c is " + set1);
     int size=set1.size();
     System.out.println("Size of set1 after adding duplicate item is " + size);
     System.out.println("Is set1 contains a " + set1);
     System.out.println("Is set1 contains c " + set1.contains("C"));
     Set<String> set2 = new TreeSet<String>();
     set2.add("E");
     set2.add("F");
     set2.add("G");
     System.out.println("Set2 is " + set2);
     set2.addAll(set1);
     System.out.println("Set2 is after mergine set1 element " + set2);
     set2.removeAll(set1);
     System.out.println("Set is after deleting set1 element " + set2);
     set2.addAll(set1);
     set2.retainAll(set1);
     System.out.println("Set2 is after deleting all element except set1 element " + set2);

 }
}
