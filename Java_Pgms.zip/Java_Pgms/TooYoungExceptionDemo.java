import java.io.*;
import java.lang.Throwable;

class TooYoungException extends RuntimeException

{

    TooYoungException(String s)
   {
       super (s);

      }

}

class TooYoungExceptionDemo

{

   public static void main(String[] args)
{

   int age=Integer.parseInt(args[0]);

  if(age>60)
{

   throw new  TooYoungException("Your age is already crossed..."); 

   }

else if(age<18)
{

   throw new TooYoungException("Please wait for sometime you are too young to wait");
  }

else
{
   System.out.println("Thanks for Registering your marriage...");
  
      }

  }

}