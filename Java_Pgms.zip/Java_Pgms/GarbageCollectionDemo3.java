import java.io.*;
public class GarbageCollectionDemo3

{
   
   public static void main(String[] args)

{

   m1();
 
   }

  public static void m1()
{

   GarbageCollectionDemo3 gc1=new GarbageCollectionDemo3();
 
    System.out.println("Value of Gc1 is ::"+gc1);

   GarbageCollectionDemo3 gc2=new GarbageCollectionDemo3();

    System.out.println("Value of GC2 is::"+gc2);

   

  }

}

