import java.io.*;
class ConstructorDemo
{

   String name;
   int rollno;
ConstructorDemo(String name,int rollno)
{

   this.name=name;
   this.rollno=rollno;

   }

public static void main(String[] args)
{

    ConstructorDemo cd=new ConstructorDemo("Kalyan",101);
    System.out.println("The value of 101 is:"+cd);
    ConstructorDemo cd1=new ConstructorDemo("Sarita",102);
    System.out.println("The value of 102 is:"+cd1);
  }

}

