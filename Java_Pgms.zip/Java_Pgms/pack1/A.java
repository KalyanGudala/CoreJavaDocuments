import java.io.*;
package pack1;

public class A

{

  public class void m1()
{

  System.out.println("Hi Helloo");

  }

}