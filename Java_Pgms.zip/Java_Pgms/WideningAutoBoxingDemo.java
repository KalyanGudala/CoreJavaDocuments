import java.io.*;
class WideningAutoBoxingDemo
{

   public static void m1(long l)
{

  System.out.println("Long Method...");
  System.out.println("Widening Method...");
 
  }

public static void m1(Integer i)

{

   System.out.println("Integer...");
   System.out.println("AutoBoxing...");
 }

public static void main(String[] args)
{

   int i=10;
   m1(i);

  }

}
