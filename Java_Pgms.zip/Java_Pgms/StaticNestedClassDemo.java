import java.io.*;
class StaticNestedClassDemo
{

  static class Inner
 
 {

    public static void main(String args[])

  {

     System.out.println("Static main Method...");

    }
       
     public static void main(String args[])

   {
    
        StaticNestedClassDemo.Inner o=new StaticNestedClassDemo().new Inner();
    

        StaticNestedClassDemo.Inner.main(args);

     }

   }

}

   

