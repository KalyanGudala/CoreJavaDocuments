import java.io.*;
class Outer
{

   class Inner
 {

   //System.out.println("In Inner class");

  }

public static void main(String args[])

{

   System.out.println("Helloo");

 }

}

