import java.io.*;
class OuterDemo4

{

   private int x=10;
   static int y=20;

  class Inner
  {
     public void m1()
    {

         System.out.println(x);
         System.out.println(y);

       }

   }
public static void main(String args[])

 {

    OuterDemo4.Inner i=new OuterDemo4().new Inner();
      i.m1();

   }

}


    