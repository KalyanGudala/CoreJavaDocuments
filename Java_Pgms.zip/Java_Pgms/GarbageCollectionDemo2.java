import java.io.*;
class GarbageCollectionDemo2
{

  public static void main(String args[])

 {

    GarbageCollectionDemo2 gc1=new GarbageCollectionDemo2();
      
         System.out.println("xxxxx is:"+gc1);

                           gc1=new GarbageCollectionDemo2();
         
         System.out.println("yyyyy is:"+gc1);

   }

}


    
