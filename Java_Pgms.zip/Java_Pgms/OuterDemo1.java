import java.io.*;
class OuterDemo1
{

   class Inner
{

   public void m1()
{

   System.out.println("Inner class method");

     
       }

   }

public static void main(String args[])
 {

    OuterDemo1 o=new OuterDemo1();
  
    OuterDemo1.Inner i=o.new Inner();

    i.m1();

      }

  }














  

