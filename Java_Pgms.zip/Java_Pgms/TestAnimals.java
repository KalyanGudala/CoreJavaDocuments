import java.io.*;
class Animal
{

  public void eat()
{

  System.out.println("Generic Animal Eating Generically");

 }

}

class Horse extends Animal{

public void eat(){

System.out.println("Horse eating hay,Oats,"+"and horse treats");

 }

}

public class TestAnimals{

public static void main(String[] args)
{

  Animal a=new Animal();//Runs the Animal Version of eat
  Animal b=new Horse();//runs the Horse version of eat
  a.eat();
  b.eat();
 }

}