import java.io.*;
import java.util.*;
public class ArrayListDemo
{

   public static void main(String[] args)throws Exception
{

   ArrayList l=new ArrayList();
           
             l.add(new Integer(10));
             l.add("A");
             l.add(null);
         System.out.println(l);
             l.remove(2);
         System.out.println(l);
             l.add(2,"M");
             l.add(0,"N"); 
         System.out.println(l);

  }

}