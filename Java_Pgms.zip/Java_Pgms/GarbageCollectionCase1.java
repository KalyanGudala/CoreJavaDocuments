import java.io.*;
import java.lang.String;

class GarbageCollectionCase1
{

   public static void main(String args[])

{

    String s=new String("Welcome to GARBAGECOLLECTION demo");

    s=null;

    System.gc();

  System.out.println("END OF MAIN METHOD");

 }

public void finalize()

{

   System.out.println("Finalize Method is called");

 }

}



