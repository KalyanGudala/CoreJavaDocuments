import java.io.*;
class GarbageCollectionDemo1
{

   public static void main(String args[])
 {
   
   GarbageCollectionDemo1 s1=new GarbageCollectionDemo1();
   GarbageCollectionDemo1 s2=new GarbageCollectionDemo1();

    s1=null;
    s2=null;

System.out.println("GC S1 value is :"+s1);
System.out.println("GC S2 value is :"+s2);

  }

}


   
