import java.io.*;
import java.util.*;
import java.lang.String;

class TestSort

{
  public static void main(String[] args)
{
  ArrayList<String> stuff=new ArrayList<String>();
                    stuff.add("Kalyan");
                    stuff.add("Gudala");
                    stuff.add("Sarita");
                    stuff.add("Gudala");
              System.out.println("Unsorted Stuff is :"+stuff);
              Collections.sort(stuff);
              System.out.println("Sorted Stuff is"+stuff);

  }
}
