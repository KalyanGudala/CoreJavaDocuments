import java.io.*;
import java.lang.Thread;
class AnonymousDemo1
{

   public static void main(String args[])

 {

    Thread t=new Thread()  //Anonymous Class Demo which extends Thread class...

 {

    public void run()
  
  {
 
       for(int i=0;i<10;i++)

     {

           System.out.println("Child Thread");

        }

     }

  };

 t.start();
 
 for(int i=0;i<10;i++)
{
   System.out.println("Main Method");

     }

   }

}



    