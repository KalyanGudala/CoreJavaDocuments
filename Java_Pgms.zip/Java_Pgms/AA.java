package pack5;
import java.io.*;

public class AA extends  P

{
  public static void main(String[] args)
{
   P p1=new P();
     p1.m1();

   AA c=new AA();

     c.m1();

   P p2=new P();

       p2.m1();
  
  
  }
   
}

