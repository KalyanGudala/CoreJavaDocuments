import java.io.*;
import java.util.*;
import java.lang.String;

public class ListIteratorDemo
{

public static void main (String[] args)

{

LinkedList l=new LinkedList();

         l.add("Kalyan");
         l.add("Karthik");
         l.add("Sarita");
         l.add("Saroja");
         l.add("Sudarshan");
System.out.println(l);

    ListIterator itr=l1.ListIterator();

    while(itr.hasNext())
{

   String s=(String)itr.next();
     if(s.equals("Sarita"))
{

    itr.remove();
    itr.set("Sarita Kalyan");
 }

System.out.println(l);
      }

   }

}