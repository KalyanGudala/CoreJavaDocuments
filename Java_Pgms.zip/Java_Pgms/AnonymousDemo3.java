import java.io.*;
import java.lang.Thread;

class AnonymousDemo3
{
   public static void main(String args[])

  {

     new Thread( 
                  new Runnable()  //Anonymous Inner class that defined inside method argument...

     {

            public void run()
            
          {

             for (int i=0;i<10;i++)

             {

                System.out.println("Child Thread");
               }

            }
     }).start();

   for(int i=0;i<10;i++)

  {

     System.out.println("Main Thread");

     }

  }

}

         



             


           

      