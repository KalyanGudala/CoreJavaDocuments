import java.io.*;
class VarargsVsGeneralMethod
{

   public static void m1(int i)
{

   System.out.println("General method....");
 
 }

public static void m1(int... i)

{

   System.out.println("Var-Arg Method...");

  }

public static void main(String args[])
{

   int i=10;

      m1(i);
   }
}
