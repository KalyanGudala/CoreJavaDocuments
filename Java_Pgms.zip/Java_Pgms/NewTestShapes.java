import java.io.*;
class GameShape
{
  public void displayShape()
{

  System.out.println("Displaying Shape");
 }

}

class PlayerPiece extends GameShape
{

  public void movePiece()
{

  System.out.println("moving game piece");

   }

}

class TilePiece extends GameShape {

public void getAdjacent()

{
 
   System.out.println("getting adjacent Tiles");
  }
}

public class NewTestShapes

{

   public static void main(String[] args)
{

  PlayerPiece player=new PlayerPiece();
  TilePiece title=new TilePiece();
  doShapes(player);
  doShapes(title);
 }
 
public static void doShapes(GameShape shape)
{

  shape.displayShape();
 }
}


