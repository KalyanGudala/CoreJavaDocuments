import java.io.*;
import java.lang.Thread;
import java.lang.Runnable;

class MyThread implements Runnable{

public void run()

{
    for(int i=0;i<=10;i++)
    
  {

     System.out.println("Child Thread");
     Thread.yield();
      }
  }
}

public class MyThreadDemo{

  public static void main(String[] args){

  MyThread mr=new MyThread();
  Thread t=new Thread(mr);
         t.start();
  for(int i=0;i<=10;i++){
   System.out.println("Main Thread");
  }

  }
}