import java.io.*;
class VarArgDemo
{

  public static void main(String[] args)
{

   m1();
   m1(10);
   m1(10,20);
   m1(10,20,30);
}

public static void m1(int... a)
{

  int total=0;

for(int i=0;i<a.length;i++)
{

  total=total+a[i];
 }

System.out.println("The Sum is:"+total);
  
  }

}