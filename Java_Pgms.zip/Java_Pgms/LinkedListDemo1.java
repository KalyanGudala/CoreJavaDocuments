import java.io.*;
import java.util.*;
class LinkedListDemo1
{

   public static void main(String[] args)throws Exception
 {

    LinkedList l1=new LinkedList();
               l1.add("Durga");
               l1.add(new Integer(10));
               l1.add(null);
               l1.add("Durga");
               l1.set(0,"Software");
               l1.add(0,"Venky");
               l1.removeLast();
               l1.addFirst("CCC");
            System.out.println(l1);

    }

}





