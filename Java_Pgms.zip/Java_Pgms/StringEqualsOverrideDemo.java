import java.io.*;
import java.lang.String;
class StringEqualsOverrideDemo
{
  public boolean equals(Object obj)
{

  try
 {
    String name1=this.name1;
    int rollno1=this.rollno1;
  
 StringEqualsOverrideDemo s=(StringEqualsOverrideDemo)obj;
  
    String name2=this.name2;
    int rollno2=this.rollno2;

if(name1.equals(name2) && rollno1==rollno2)
{
   
   return true;
 }

else
 {
   return false;

  }
}
catch(ClassCastException e)
{
   return false;
  
  }

catch(NullPointerException e)
{

  return false;
   }

}

public static void main (String[] args)
{

   StringEqualsOverrideDemo s1=new StringEqualsOverrideDemo("Kalyan",101);
   StringEqualsOverrideDemo s2=new StringEqualsOverrideDemo("Sarita",102);
   StringEqualsOverrideDemo s3=new StringEqualsOverrideDemo("Karthik",103);
   StringEqualsOverrideDemo s4=new StringEqualsOverrideDemo("Kalyan",101);

  System.out.println(s1.equals(s2));
  System.out.println(s1.equals(s3));
  System.out.println(s1.equals(s4));
  System.out.println(s1.equals("Kalyan"));
  System.out.println(s1.equals(null));
 }

}