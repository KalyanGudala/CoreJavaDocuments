
import java.io.*;
import java.util.*;
public class LinearSearchCount 

{ 
   public LinearSearchCount() 

    { 

        } 

    public static int countNumberOfOccurances(int[] a, int n, int k) 

    { 

        int resultSearchValue = linearSearchCount(a, n, k); 

        if (resultSearchValue == -1) 

        { 
             return 0; 

           } 

        else 

        { 
            return resultSearchValue; 

        } 

    } 

    public static int linearSearchCount(int[] a, int n, int k) 

    { 
          int count = 0;   
        for (int i = 0; i < n; i++) 

        { 

            if (a[i] == k) 

            { 

                count++; 

               } 

        }
  

        return count; 

    } 

    public static void main(String[] args) 

    { 

        //  Input Array 


        int[] a = { 1, 2, 3, 4, 4, 4, 4, 5 }; 
  
        //  k - Element to be found 

        int k = 4; 

        //  n - Size of the array 

        int n = 8; 

        System.out.println(countNumberOfOccurances(a, n , k)); 

    } 


} 
