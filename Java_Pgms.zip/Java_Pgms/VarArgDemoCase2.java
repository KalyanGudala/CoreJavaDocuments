import java.io.*;
class VarArgDemoCase2
{

   public static void m1(Object O)
{

   System.out.println("Object Method");
 
 }

public static void main(String args[])
{

   int i=10;
   m1(i);

 }

}


 