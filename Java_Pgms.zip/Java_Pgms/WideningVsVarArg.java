import java.io.*;
class WideningVsVarArg
{

   public static void m1(int i)
{

   System.out.println("Widening Method...");

 }

  public static void m1(byte... b) 
{

  System.out.println("Var-Arg Method....");

 }

public static void main(String args[])

 {

    byte b=10;

   m1(b);
 }

}