import java.io.*;
class OuterDemo8
{

   int x=10;
   static int y=10;

  public void m1()
{
  int i=10;

  static int j=20;

class Inner
{

   int k=30;
   static int l=40;

public void m2()
{

   System.out.println("value of x is:"+x);
   System.out.println("value of y is:"+y);
   System.out.println("value of j is:"+j);
   System.out.println("value of k is:"+k);
   System.out.println("value of l is:"+l);

        }

     }

  }

}

