import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class CheckCookie extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		Cookie cookie[]=request.getCookies();
		pw.println("<HTML><BODY BGCOLOR=wheat><H2>");
		pw.println("Hai "+cookie[0].getValue()+" ! hope enjoying the Cookies here</H2>");
		pw.println("</BODY>");
		pw.println("</HTML>");
		pw.close();
	}//method close
	
}