import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class RetrieveServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		ServletContext sc=getServletContext();
		String mail= (String)sc.getAttribute("mail");
		String phone= (String)sc.getAttribute("telephone");
		String adminMail=sc.getInitParameter("admin");
		pw.println("<HTML>");
		pw.println("<BODY BGCOLOR=cyan>");
		pw.println("<H2>Your Personal Details</H2>");
		pw.println("<H3>Email ID:"+mail+"</H3>");
		pw.println("<H3>Telephone #:"+phone+"</H3>");
		pw.println("<H3>Web site admin is avaialable at "+adminMail+"</H3>");
		pw.println("</BODY>");
		pw.println("</HTML>");
		pw.close();
	}
}