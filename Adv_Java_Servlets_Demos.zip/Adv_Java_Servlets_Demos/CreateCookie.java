import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class CreateCookie extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		String name=request.getParameter("user");
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		Cookie cookie= new Cookie("user",name);
		response.addCookie(cookie);
		pw.println("<HTML>");
		pw.println("<BODY BGCOLOR=wheat><CENTER>");
		pw.println("<H2><A HREF=./check>SHOPPING GOES HERE</A></H2>");
		pw.println("</CENTER></BODY></HTML>");
		pw.close();
		
	}
}