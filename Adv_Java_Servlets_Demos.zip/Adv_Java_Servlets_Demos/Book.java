package bookpack;
import java.io.*;
import java.lang.*;
public class Book
{
	private int isbn;
	private String title;
	public void setIsbn(int isbn)
	{
		this.isbn=isbn;
	}
	
	public int getIsbn()
	{
		return isbn;
	}
	
	public void setTitle(String title)
	{
		this.title=title;
	}
	
	public String getTitle()
	{
		return title;
	}
}