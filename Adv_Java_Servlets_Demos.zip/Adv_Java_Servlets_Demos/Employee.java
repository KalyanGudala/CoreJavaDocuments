package beanpack;
import java.sql.*;
import java.io.Serializable;
public class Employee implements Serializable
{
	Connection con;
	private int empno;
	private String name;
	private float salary;
	
	public Employee()
	{
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin://@localhost:1521/orcl","scott","Tiger");
		}
		
		catch(Exception ex)
		{
			
		}
	}
	
	public void setEmpno(int empno)
	{
		this.empno=empno;
		results();
	}
	
	public int getEmpno()
	{
		return this.empno;
	}
	
	public void setName(String name)
	{
		this.name=name;
		
	}
	
	public String getName()
	{
		return this.name;
		
	}
	
	public void setSalary(float salary)
	{
		this.salary=salary;
		
	}
	
	public float getSalary()
	{
		return this.salary;
		
	}
	
	public void results()
	{
		try
		{
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select * from scott.emp where empno="+empno);
			rs.next();
			name=rs.getString("empname");
			salary=rs.getFloat("sal");
		}
		catch(Exception e)
		{
			
		}
	}
}
