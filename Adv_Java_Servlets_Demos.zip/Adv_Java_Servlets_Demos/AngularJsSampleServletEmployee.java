import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class AngularJsSampleServletEmployee extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		PrintWriter out=response.getWriter();
	out.println("[{\"empid\":1,\"empname\":\"Kalyan\",\"salary\":70000},{\"empid\":2,\"empname\":\"Saritha\",\"salary\":75000},"
			+"{\"empid\":3,\"empname\":\"Scott\",\"salary\":75000},{\"empid\":4,\"empname\":\"Smith\",\"salary\":80000},"
			+"{\"empid\":5,\"empname\":\"John\",\"salary\":80000}]");
	}
}