import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class TargetServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
	   response.setContentType("text/html");
	   PrintWriter pw=response.getWriter();
	   HttpSession session=request.getSession();
	   String user= (String)session.getAttribute("usr");
	   pw.println("<HTML>");
	   pw.println("<BODY BGCOLOR=wheat>");
	   pw.println("Hai"+user+"! HOPE YOU ARE ENJOYING SHOPPING HERE</H2>");
	   pw.println("</BODY>");
	   pw.println("</HTML>");
	   pw.close();
	 }
}	 