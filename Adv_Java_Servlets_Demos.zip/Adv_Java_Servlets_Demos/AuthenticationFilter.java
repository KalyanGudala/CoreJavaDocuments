import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class AuthenticationFilter implements Filter
{
	Connection con;
	ServletContext sc;
	public void init(FilterConfig config)throws ServletException
	{
		String driver=config.getInitParameter("driver");
		String url=config.getInitParameter("url");
		String uname=config.getInitParameter("user");
		String password=config.getInitParameter("pwd");
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,uname,password);
			System.out.println("Connection Established Sucessfully!!...");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		sc=config.getServletContext();
	} /// init()close
	
	public void doFilter(ServletRequest request,ServletResponse response,FilterChain filterchain)throws IOException,ServletException
	{
		Statement stm=null;
		ResultSet rs=null;
		String user=request.getParameter("user");
		String pwd=request.getParameter("password");	
		try
		{
			stm=con.createStatement();
			String sql="SELECT * FROM SCOTT.USERS WHERE USERNAME='"+user+"' AND PASSWORD='"+pwd+"'";
			rs=stm.executeQuery(sql);
			
			if(rs.next())
				filterchain.doFilter(request,response);
			else
				sc.getRequestDispatcher("/error.html").forward(request,response);
		} //try close	
			catch(Exception e)
			{
				e.printStackTrace();
			}//catch close
			
			finally
			{
				try
				{
					if(rs!=null)
						rs.close();					
					if(stm!=null)
						stm.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			
		//doFilter() close
	}
	public void destroy()
	{
		try
		{
			if(con!=null)
				con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}//destroy() close
}