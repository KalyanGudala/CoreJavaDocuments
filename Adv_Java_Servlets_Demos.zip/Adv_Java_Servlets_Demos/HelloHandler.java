package hellopack;
import javax.servlet.jsp.JspException;  
import javax.servlet.jsp.JspWriter;  
import javax.servlet.jsp.tagext.TagSupport;  
public class HelloHandler extends TagSupport
{
	public int doStartTag()throws JspException
	{
		try
		{
			JspWriter out=pageContext.getOut();
			out.println();
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return SKIP_BODY;
	}
}