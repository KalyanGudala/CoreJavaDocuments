import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class GreetingServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		String name=request.getParameter("greet");
		String message="HELLO!"+name;
        response.setContentType("text/html");
        PrintWriter outstream=response.getWriter();
        outstream.println("<HTML>");
        outstream.println("<BODY BGCOLOR=cyan>");
        outstream.println("<H3>"+message+"<H3>");
        outstream.println("</BODY>");
        outstream.println("</HTML>");	
        outstream.close();		
	}
}
