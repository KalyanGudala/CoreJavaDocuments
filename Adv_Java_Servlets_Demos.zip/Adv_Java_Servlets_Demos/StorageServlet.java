import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class StorageServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		ServletContext sc=getServletContext();
		sc.setAttribute("mail",email);
		sc.setAttribute("telephone",phone);
		String adminMail=sc.getInitParameter("admin");
		pw.println("<HTML>");
		pw.println("<BODY BGCOLOR=wheat>");
		pw.println("<H3>Web site admin is avaialable at "+adminMail+"</H3>");
		pw.println("<H2><A HREF=./retrieve>GET YOUR DETAILS HERE</A></H2>");
		pw.println("</BODY>");
		pw.println("</HTML>");
		pw.close();
	}
	
}