package reqscopepack;
import java.io.*;
import java.lang.*;
public class EmployeeRequestScope
{
	private int empNo;
	private String name;
	public void setempNo(int empNo)
	{
		this.empNo=empNo;
	}
	
	public int getempNo()
	{
		return empNo;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getName()
	{
		return name;
	}
}