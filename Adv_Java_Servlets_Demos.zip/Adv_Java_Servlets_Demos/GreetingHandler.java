package greetpack;
import javax.servlet.jsp.JspException;  
import javax.servlet.jsp.JspWriter;  
import javax.servlet.jsp.tagext.TagSupport;  
import java.io.*;

public class GreetingHandler extends TagSupport
{
	private  String name;
	private int age;
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getName()
	{
		return this.name=name;
	}
	
	public void setAge(int age)
	{
		this.age=age;
	}
	public int getAge()
	{
		return this.age=age;
	}
	
	public int doStartTag()throws JspException
	{
		try
		{
			JspWriter out=pageContext.getOut();
			out.println("Hello"+name+"you are"+age+"years old");
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return SKIP_BODY;
	}
}