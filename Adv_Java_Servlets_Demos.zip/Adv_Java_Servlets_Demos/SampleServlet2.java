import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class SampleServlet2 extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
	{
		String str=request.getParameter("searchstr");
		PrintWriter pw=response.getWriter();
		
		ArrayList<Employee> employee=new ArrayList<Employee>();
		employee.add(new Employee(1,"Kalyan",70000));
		employee.add(new Employee(2,"Sarith",80000));
		employee.add(new Employee(3,"John",80000));
		employee.add(new Employee(4,"Scott",70000));
		employee.add(new Employee(5,"Abdul",80000));
		
		ArrayList<Employee> employee1=new ArrayList<Employee>();
		for(int i=0;i<employee.size();i++)
		{
			if(employee.get(i).empname.indexOf(str)>=0)
			{
				employee1.add(employee.get(i));
			}
		}
		
		String s ="[";
		
		for (int i=0;i<employee1.size();i++)
		{
			s+="{\"empid\":\""+employee1.get(i).empid+"\",\"empname\":\""+employee1.get(i).empname+"\",\"salary\":\""+employee1.get(i).salary+"\"}";
			
			if(i<employee1.size()-1)
			{
				s+=",";
			}
		}
		s+="]";
		pw.println(s);
			}
		}
		
		class Employee{
			
			public int empid;
			public String empname;
			public int salary;
			
			public Employee (int empid,String empname,int salary)
			{
				this.empid=empid;
				this.empname=empname;
				this.salary=salary;
				
			}
			
		}
		
	
