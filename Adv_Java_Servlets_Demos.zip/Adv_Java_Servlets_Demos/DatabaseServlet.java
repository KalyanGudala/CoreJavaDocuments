import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class DatabaseServlet extends HttpServlet
{
	Connection con;
	public void init()throws ServletException
	{
		String driver=getInitParameter("driver");
		String url=getInitParameter("url");
		String uname=getInitParameter("user");
		String password=getInitParameter("pwd");
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,uname,password);
			System.out.println("Connection Established Sucessfully!!...");
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println(ex);
		}
		catch(SQLException sqe)
		{
			System.out.println("Unable to Establish a Connection..!!");
		}
	} /// init()close
	
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		try{
			pw.println("<HTML>");
			pw.println("<BODY BGCOLOR=wheat>");
			pw.println("<CENTER>");
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("SELECT * FROM SCOTT.EMP WHERE EMPNO="+request.getParameter("empno"));
			ResultSetMetaData metadata=rs.getMetaData();
			int count=metadata.getColumnCount();
			if(rs.next())
			{
				pw.println("<H2> EMPLOYEE DETAILS</H2>");
				pw.println("<TABLE BORDER=1 CELLPADDING=3 CELLSPACING=0>");
				pw.println("<TR>");
				for(int i=1;i<=count;i++)
				pw.println("<TH align=right width=100>"+metadata.getColumnName(i)+"</TH>");
				pw.println("</TR>");
				pw.println("<TR>");
				for(int i=1;i<=count;i++)
				pw.println("<TD align=right width=100>"+rs.getString(i)+"</TD>");
			    pw.println("</TR>");
				pw.println("</TABLE>");
			}//if close
			else
			{
				pw.println("<H2> EMPLOYEE RECORDS NOT FOUND</H2>");
				pw.println("</CENTER>");
				pw.println("</BODY>");
				pw.println("</HTML>");
				pw.close();
				rs.close();
				stm.close();						
			}
			
		}//try close
		catch(SQLException sqe)
		{
			System.out.println(sqe);
		}
	}//doGet close
	
	public void destroy()
	{
		if(con!=null)
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{
				System.out.println("Connection closed Sucessfully!!...");
			}
		}
	}
}