import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class InsertSampleServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request , HttpServletResponse response)throws ServletException,IOException
	{
		String empid=request.getParameter("empid");
		String empname=request.getParameter("empname");
		String salary=request.getParameter("salary");
		
		//write code for inserting
		PrintWriter pw=response.getWriter();
		pw.println("Successfullly Inserted..!!");
		
	}
}