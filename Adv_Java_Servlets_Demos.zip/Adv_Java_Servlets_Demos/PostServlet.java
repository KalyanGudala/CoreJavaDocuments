import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class PostServlet extends HttpServlet
{
	Connection con;
	PreparedStatement pstm;
	public void init()throws ServletException
	{
		String driver=getInitParameter("driver");
		String url=getInitParameter("url");
		String uname=getInitParameter("user");
		String password=getInitParameter("pwd");
		try
		{
			Class.forName(driver);
			con=DriverManager.getConnection(url,uname,password);
			System.out.println("Connection Established Sucessfully!!...");
			pstm=con.prepareStatement("INSERT INTO SCOTT.EMP VALUES(?,?,?)");
			
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println(ex);
		}
		catch(SQLException sqe)
		{
			System.out.println("Unable to Establish a Connection..!!");
		}
    } /// init()close
	
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		int empNo=Integer.parseInt(request.getParameter("empno"));
		String empName=request.getParameter("empname");
		float empSalary=Float.parseFloat(request.getParameter("empsalary"));
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		try{
			
			pstm.setInt(1,empNo);
			pstm.setString(2,empName);
			pstm.setFloat(3,empSalary);
			pstm.executeUpdate();
			RequestDispatcher rd=request.getRequestDispatcher("employeeInsert.html");
			rd.include(request,response);
		}
		catch(SQLException sqe)
		{
			System.out.println(sqe);
		}
	}//doPost() Close
	public void destroy()
	{
		if(pstm!=null)
		{
			try
			{
				pstm.close();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		
		if(con!=null)
		{
			try
			{
				con.close();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			System.out.println("Connection Closed Successfully..!!");
		}
	}//destroy() close
}