import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class SourceServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		String name=request.getParameter("user");
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		session.setAttribute("usr",name);
		pw.println("<HTML>");
		pw.println("<BODY BGCOLOR=wheat><CENTER>");
		pw.println("<H2><A HREF="+response.encodeURL("./target")+">GET USER NAME HERE</A></H2>");
		pw.println("</CENTER></BODY></HTML>");
		pw.close();
		
	}
}