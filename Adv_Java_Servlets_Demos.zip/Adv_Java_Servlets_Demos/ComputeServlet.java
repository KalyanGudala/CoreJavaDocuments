import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class ComputeServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException
	{
		int n1=Integer.parseInt(request.getParameter("t1"));
		int n2=Integer.parseInt(request.getParameter("t2"));
		int result=0;
		String submit=request.getParameter("click");
		System.out.println(submit);
		if(submit.equals("add"))
			result=n1+n2;
		else
			result=n1-n2;
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<HTML>");
		out.println("<BODY>");
		out.println("<H3> The result is:"+result+"</H3>");
		out.println("</BODY>");
		out.println("</HTML>");
		
	}
}