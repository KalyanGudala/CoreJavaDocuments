package com.servlet;
import beanpack.Employee;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.lang.*;

public class MVCControllerServlet extends HttpServlet 
{
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException
	{
		int empno=Integer.parseInt(request.getParameter("empno"));
		Employee ebean=new Employee();
		ebean.setEmpno(empno);	
		getServletContext().setAttribute("ebean",ebean);
		getServletContext().getRequestDispatcher("/view.jsp").forward(request,response);
	}
}