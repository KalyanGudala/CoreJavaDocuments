import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class GrossServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		float basic=Float.parseFloat(request.getParameter("basic"));
		float da=0.5f*basic;
		float hra=0.4f*basic;
		float gross=basic+da+hra;
		Float f=new Float(gross);
		request.setAttribute("gross",f);
		ServletContext sc=getServletContext();
		RequestDispatcher rd=sc.getRequestDispatcher("/net");
		rd.forward(request,response);
	}
}