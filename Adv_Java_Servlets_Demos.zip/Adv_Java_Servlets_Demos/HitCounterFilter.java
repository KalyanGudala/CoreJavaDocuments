import javax.servlet.*;
import java.io.*;

public class HitCounterFilter implements Filter
{
	ServletContext sc;
	int count;
	public void init(FilterConfig filtercofig) throws ServletException
	{
		sc=filtercofig.getServletContext();
	}//init() close
	
	public void doFilter(ServletRequest request,ServletResponse response,FilterChain filterchain)throws IOException,ServletException
	{
		filterchain.doFilter(request,response);
		count++;
		sc.log("Number Of Times Request came to LoginServlet..!!"+count);
	}//doFilter() close
	
	public void destroy()
	{
		
	}//destroy() close
}