import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class NetServlet extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		Float gross=(Float)request.getAttribute("gross");
		float net=gross.floatValue()-2000-1000;
		ServletContext sc=getServletContext();
		RequestDispatcher rd=sc.getRequestDispatcher("/caption.html");
		rd.include(request,response);
		pw.println("<HTML>");
		pw.println("<BODY BGCOLOR=cyan>");
		pw.println("YOUR NET SALARY IS: "+net);
		pw.println("</BODY>");
		pw.println("</HTML>");
		pw.close();
	}
}