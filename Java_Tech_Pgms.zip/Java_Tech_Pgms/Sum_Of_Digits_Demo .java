import java.io.*;
class Sum_Of_Digits_Demo
{
  public static void main(Sting[] args)
 {
   int temp=n;
   int count=0;
   int sum=0;
   while(n>0)
  {
   sum=sum+n%10;
   n=n/10;
   count ++;
 }

 System.out.println("The number is:"+temp);
 System.out.println("The sum of digits is:"+sum);
 System.out.println("The number of digits is.."+count);
  }

}
