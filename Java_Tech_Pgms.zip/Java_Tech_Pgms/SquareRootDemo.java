import java.io.*;
public class SquareRootDemo
{
  public static void main(String[] args)

{
  System.out.println(Math.sqrt(9));
  System.out.println(Math.sqrt(25.5));
  }
}