import java.io.*;
public class ReverseStringDemo
{
  public static void main(String[] args)
 {
   String str="This is String Reverse Demo Example";
   System.out.println(ReverseString.reverseIt(str));
  }
}

class ReverseString
{

  public static String reverseIt(String source)
{
   int i;
   int len=source.length();
   StringBuffer dest=new StringBuffer(len);
   for(i=(len-1); i>=0 ; i--)
   dest.append(source.charAt(i));
   return dest.toString();
 }

}


  
   
     
