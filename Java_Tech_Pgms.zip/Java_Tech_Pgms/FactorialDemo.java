import java.io.*;
class FactorialDemo
{

  public static void main(String[] args)
 {
   try
    {
      BufferedReader br=new BufferedReader (new InputStreamReader(System.in)); 
      System.out.println("Enter Number");
      int num=Integer.parseInt(br.readLine());
      int fact=1;;
      System.out.println("Factorial of the Number is:" +num+ ":");
      for(int i=1;i<=num;i++)
      {
         fact=fact*i;
        }

     System.out.println(fact);
  }

catch(Exception e)
{
     }

  }

} 