import java.io.*;
public class PalindomeDemo
{
  public static void main(String [] args)
{

  try
     {

       BufferedReader br=new BufferedReader (new InputStreamReader(System.in)); 
       System.out.println("Enter Number");
       int num=Integer.parseInt(br.readLine());
       int rev=0;
       int n=num;
       System.out.println("Number:");
       System.out.println(" "+num);
       for(int i=0;i<=num;i++)
       {

          int r=num%10;
          num=num/10;
          rev=rev*10+r;
          i=0;
        }

 System.out.println("After reversing the number is:"+ "");
 System.out.println(""+rev);
 if(n==rev)
 {
   System.out.println("Number is Palindrome:");
  }
else{
     System.out.println("Number is not Plaindrome");

     }

}

catch(Exception e)
{

  System.out.println("Out oF Range:");
 }

 }
}
    
           

