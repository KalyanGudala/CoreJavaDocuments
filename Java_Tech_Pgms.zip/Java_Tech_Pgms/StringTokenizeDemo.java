import java.io.*;
import java.util.*;
public class StringTokenizeDemo
{
  public static void main(String[] args)
{
  String str="It is a String Tokenizer Demo";

  StringTokenizer st= new StringTokenizer(str," ");

  System.out.println("The Tokens are:");

  while(st.hasMoreTokens())
{
  String s1=st.nextToken();

  System.out.println(s1);
  
    }
  }

 }