import java.util.*;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class EmployeeSort{

public static void main(String[] args)
{
  List employees=new ArrayList();
  employees.add(new Employee(10,"Dinesh",18000));
  employees.add(new Employee(16,"Pankaj",19000));
  employees.add(new Employee(13,"Mayur",14000));
  employees.add(new Employee(9,"Praveen",22000));
  System.out.println("...Sort By Employee Id...");
  Collections.sort(employees,new EmployeeSortById());
  printEmployees(employees);
  System.out.println("...Sort By EmployeeByName...");
  Collections.sort(employees,new EmployeeSortByName());
  printEmployees(employees);

 }

public static void printEmployees(List employees) 
{
  for(Employee e: employees)
  {
    System.out.println("Id:"+e.empId+"Names:"+e.empName+"Salary:"+e.empSalary);
   }
 }
}

 //Employee Object
 
class Employee
{
  public int empId;
  public String empName;
  public double empSalary;

 public Employee(int empId,String empName,double empSalary) 
 
{
   this.empId=empId;
   this.empName=empName;
   this.empSalary=empSalary;

 }

}

//Sort By employee id

class EmployeeSortById implements Comparator
 {
   public int compare(Employee emp1,Employee emp2)
   {
     int value=0;   
    if(emp1.empId > emp2.empId)
       value=1;
    else if(emp1.empId > emp2.empId)
       value=-1;
    else if(emp1.empId == emp2.empId)
       value=0;
    return value;
    
      }

 }

//sort by Name

class EmployeeSortByName implements Comparator
 {
   public int Compare(Employee emp1,Employee emp2)
   {
     return emp1.empName.compareTo(emp2.empName);
    }

  }



 



 


